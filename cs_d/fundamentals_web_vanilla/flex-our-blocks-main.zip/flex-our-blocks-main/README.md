# flex-our-blocks
#### recreating the example clone.png, the goal is to use CSS, flex, margin, padding to achieve this.
