# user-card
### tasked with replication html and stylings for a user card. Customizing to make it your own.
#### this is the second iteration of this project, where I approached with better understanding of CSS Position properties.
#### allowed for less code, better readability and responsiveness.

###### i want a readme
