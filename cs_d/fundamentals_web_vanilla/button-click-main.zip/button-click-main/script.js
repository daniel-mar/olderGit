var botbtn = 0
var midbtn = 0

function botchange(element){
    botbtn++;
    element.innerText = `${this.botbtn}` + ' likes';
}

function midchange(element){
    midbtn++;
    element.innerText = `${this.midbtn}` + ' likes';
}

function alertninja() {
    alert('"Ninja was liked"');

}