# plotting-blocks
### tasked with recreating with CSS to format content as clone png
