# dictionary-entry
#### clone the dictionary entry page using HTML & CSS
