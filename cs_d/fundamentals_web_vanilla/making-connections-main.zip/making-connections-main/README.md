# making-connections
### JavaScript tracking of numbers of requests to remove that card when no more requests.
### Allow user to edit profile by introducing a textbox to change profile name.
### Update value for your connections.  CSS effects for accept or deny connection requests buttons. 

![alt-text](https://github.com/daniel-mar/making-connections/blob/main/making-connections.gif)
