/* store innerTexts of username  */
var username = document.getElementById("username").innerText;

/* store the element, to use for removing of the CARDS  */
var cardRQ = document.getElementById("conn-rq");

/* store to use in add or removal calls */
var phil = document.getElementById("phil");
var todd = document.getElementById("todd");

/* store first 3 characters and parse values for incrementing */
var yourConnects = document.querySelector('#your-conn .badge').innerHTML.substring(0,3);
yourConnects = parseInt(yourConnects);

/* store and parse values for decrementing */
var numRequests = document.querySelector("#conn-rq span").innerHTML;
numRequests = parseInt(numRequests);

/* add, remove user card functionality 
    checks for when requests are == 0, and deletes the card for that when 0
    when a request is accepted, it adds to the number of requests. I decided to keep the + in the output
    but if it wasn't there on load, and was exact values, the output would be the exact value anyways
*/

let addPhil = function() {
    phil.remove();
    numRequests--;
    yourConnects++;
    document.querySelector('#conn-rq span').innerText = numRequests;
    if(document.querySelector('#conn-rq span').innerText == 0) {
    cardRQ.remove();
    }
    document.querySelector('#your-conn .badge').innerText = yourConnects + "+";
}

let addTodd = function() {
    todd.remove();
    numRequests--;
    yourConnects++;
    document.querySelector('#conn-rq span').innerText = numRequests;
    if(document.querySelector('#conn-rq span').innerText == 0) {
    cardRQ.remove();
    }
    document.querySelector('#your-conn .badge').innerText = yourConnects + "+";
}

let removeTodd = function() {
    todd.remove();
    numRequests--;
    document.querySelector('#conn-rq span').innerText = numRequests;
    if(document.querySelector('#conn-rq span').innerText == 0) {
    cardRQ.remove();
    }
}

let removePhil = function() {
    phil.remove();
    numRequests--;
    document.querySelector('#conn-rq span').innerText = numRequests;
    if(document.querySelector('#conn-rq span').innerText == 0) {
    cardRQ.remove();
    }
}

/* edit profile on click function */

let editProfile = function() {

    if(!document.querySelector("input")) {

    var input = document.createElement("input");
    var parent = document.getElementById("insert");
    input.setAttribute('type', 'text');
    parent.appendChild(input);
    document.querySelector("input").addEventListener('keyup', function(event) {
        if ( event.code == 'Enter' ) {
            var inputtedText = document.querySelector("input").value;
            document.getElementById("username").innerText = inputtedText;
            input.remove();
            }
        });
    }
}
// PSEUDO CODE
// when we click settings, it creates a text input, meaning there is only 1 of those on the page
// if there is not an input on the page, we can track that, grab the value on submit or on "event-code == 'Enter'"
// look for a key up event listener, meaning when we press down on enter, and release, that means we submitted
// we can store the value of the input.innertext. remove that input, and use the variable to push to the h1

