# registration-form
#### tasked to clone a html registation form as well as style it.
##### here is my take on that, attached: original image and completed customized clone
