var totalLikes = [19, 28, 37];

function topClick() {
    document.getElementById('top-like').innerText = totalLikes[0]++;
}

function midClick() {
    document.getElementById('mid-like').innerText = totalLikes[1]++;
}

function botClick() {
    document.getElementById('bot-like').innerText = totalLikes[2]++;
}