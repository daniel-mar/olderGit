# rng_game_sessions

When running server, creates a dynamic guessing game that tracks user input. Giving them 5 attempts to guess a randomly generated number with feedback provided whether their guess was too high or too low, until correct or out of lives. Once out of lives, stops ability to have valid guesses and displays number. You may reset the game at any time.

At game reset, clears sessions and starts again ready for user input
