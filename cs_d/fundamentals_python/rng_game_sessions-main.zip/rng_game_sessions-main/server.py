from flask import Flask, render_template, redirect, request, session
app = Flask(__name__)
app.secret_key = "12312f1fasdadqwd8"

import random


#======================================
# Root Route - Renders Form
#======================================
@app.route("/")
def index():
# check to see if guess exists, if not, create it.    
    if "comp_guess" in session:
        print("Computer's guess = " + str(session["comp_guess"]))
    else:
        session["comp_guess"] = random.randint(1, 100)
    if "comparison" not in session:
        session["comparison"] = "none"
        session["counter"] = 0
    return render_template("index.html", comparison = session["comparison"],
    counter = session["counter"], thenumber = session["comp_guess"])
# we send comparison, counter and thenumber to create elements on certain events
#======================================
# Process Form
#======================================
@app.route("/processing", methods=["post"])
def process():
    if session["counter"] < 6: 
        print(request.form)

        session["counter"] = session["counter"] + 1

        if request.form["guess"] != "":
            user_guess = int(request.form["guess"]) 
        else:
            return redirect("/")

        comp_guess = session["comp_guess"]

        if comp_guess > user_guess:
            session["comparison"] = "low"
        elif comp_guess < user_guess:
            session["comparison"] = "high"
        else:
            session["comparison"] = "perfect"
    else:
        return redirect("/")

    print(session["comparison"])
    return redirect("/")


#======================================
# Reset Game
#======================================

@app.route("/reset")
def reset():
    session.clear()
    return redirect("/")



if __name__=="__main__":
    app.run(debug=True)