from flask import Flask, render_template, redirect, session, request

app = Flask(__name__) # creates an instance utilizing the Flask framework and store it as 'app'
app.secret_key = "13nsjef4u1023"

# SECOND CHUNK
# create your routes below
@app.route('/')
def index():
    print('*******SUCCESSFUL**PAGE**LOAD********')
    # checking if a key exists, if not, create key
    print('*******ENTERING_IF_KEY_EXISTS********')
    if "counter" in session:
        print('***key is in session***')
        session['counter'] = session['counter'] + 1 # onload, increment count by 1
        print('we added 1 to counter')

    else:
        print('**no key in session, creating now**')
        session['counter'] = 1

    return render_template('index.html', counter = session['counter'])


#=============================================
# ADD 2 - button click
#=============================================
# try sessions to see if page load and operations were successful
@app.route('/two_visits')
def addTwo():
    try:
        print('successful increment by 2 pageload')
        # increment count by 1, remember onload increments by 1, thus it is 2
        session['counter'] = session['counter'] + 1
    except:
        print("that try didn't work on increment 2 page load") 

    return redirect('/')

#=============================================
# CLEAR SESSION COOKIE - DELETE COUNTER
#=============================================
@app.route('/destroy_session')
def goDestroy():
    try:
        session.clear()
        print('session has been cleared')
    except:
        print('did not load page, or try did not complete')
    return redirect('/')

# FINAL CHUNK for server; if statement to allow the server to run
if __name__ == "__main__":
    app.run(debug=True)