# sessions_counter

NOTE: Not hosted on github pages because it is server practice for redirect, sessions mostly, functionality will not run without server running

#### Objective to use server to create sessions and get accustomed to receiving POST requests and what to do with them. Practice debugging your server and routes to be able to have the site running and performing your desired calculations with session. 
