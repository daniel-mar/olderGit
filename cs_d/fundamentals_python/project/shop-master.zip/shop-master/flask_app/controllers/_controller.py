from flask import Flask, render_template, request, redirect, session, flash
from flask_app import app

from flask_app.models.item import Item
from flask_app.models.deleted import Deleted


# ==========================
# Dashboard | View all items
# ==========================
@app.route('/')
def index():
    # login wall to view point reward content
    all_items = Item.all_items()

    # all of the deletions to be viewed
    all_deletions = Deleted.all_deletions()
    return render_template("index.html", all_items = all_items, deleted_items = all_deletions)