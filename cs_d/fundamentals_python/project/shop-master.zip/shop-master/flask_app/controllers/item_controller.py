from pydoc import describe
from flask import render_template, redirect, session, request, flash
from flask_app import app

from flask_app.models.item import Item
from flask_app.models.deleted import Deleted

# =========================
# Adding a new item webpage
# =========================
@app.route('/add/item')
def add():

    return render_template('add_item.html')

# ======================================
# Creating a new item: view in dashboard
# ======================================
@app.route('/create/item', methods = ['POST'])
def createItem():

    data = {
        'name' : request.form['name'],
        'description' : request.form['description']
    }

    # call model to create the item
    Item.add_item(data)
    # redirect to dashboard after POST
    return redirect('/')

# =============================
# Edit an existing item webpage
# =============================
@app.route('/edit/item/<int:item_id>')
def edit_item(item_id):

    data = {
        "item_id" : item_id
    }
    item = Item.get_one_item(data)
    print(item)

    return render_template('edit_item.html', item = item)

# ===============================
# Update an existing editted item
# ===============================
@app.route('/update/item/<int:item_id>', methods=['POST'])
def update_item(item_id):
    data = {
        'name' : request.form['name'],
        'description' : request.form['description'],
        "item_id" : item_id
    }
    Item.update_item(data)

    return redirect('/')

# ============================
# Delete an existing item page
# ============================
@app.route('/delete/item/<int:item_id>')
def delete_item(item_id):
    data = {
        "item_id" : item_id
    }
    item = Item.get_one_item(data)

    return render_template('delete_item.html', item = item)

# ========================================
# Confirms the deletion of item from table
# ========================================
@app.route('/destroy/item/<int:item_id>', methods=['post'])
def destroy_item(item_id):
    print(request.form)
    data = {
        "item_id" : item_id,
        "name" : request.form['name'],
        "description" : request.form['description'],
        "comments" : request.form['comments']
    }

    deleted_item = Item.delete_item(data)
    print(deleted_item)
    return redirect('/')

# ========================================
# Undelete item and restore in items table
# ========================================
@app.route('/undelete/item/<int:item_id>')
def undelete_item(item_id):
    data = {
        "item_id" : item_id
    }
    to_restore = Deleted.get_one_deleted(data)
    # have access to the data, clean it for the next query to restore
    restore_data = {
        "name" : to_restore.name,
        "description" : to_restore.description,
    }
    # add item back into table
    Item.add_item(restore_data)

    # remove from deletions table
    Deleted.final_delete(data)

    return redirect('/')