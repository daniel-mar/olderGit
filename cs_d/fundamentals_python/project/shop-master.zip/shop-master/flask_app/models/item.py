from flask_app.config.mysqlconnection import connectToMySQL

class Item:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    # Adding an item | works in add item page
    @classmethod
    def add_item(cls, data):
        query = "INSERT INTO items (name, description, created_at, updated_at) VALUES( %(name)s, %(description)s, NOW(), NOW() );"
        return connectToMySQL('shop_db').query_db(query, data)

    # View all items | works in dashboard page
    @classmethod
    def all_items(cls):
        query = "SELECT * from items"
        results = connectToMySQL('shop_db').query_db(query)
        return results

    # View one item | works in edit page
    @classmethod
    def get_one_item(cls, data):
        query = "SELECT * FROM items WHERE id = %(item_id)s;"
        results = connectToMySQL('shop_db').query_db(query, data)
        return cls(results[0])

    # Update selected item | works on button click
    @classmethod
    def update_item(cls, data):
        query = "UPDATE items SET name = %(name)s, description = %(description)s, updated_at = NOW() WHERE id = %(item_id)s;"
        return connectToMySQL('shop_db').query_db(query, data)

    # Delete selected item | 
    @classmethod
    def delete_item(cls, data):
        # when deleted
        save = "INSERT INTO deletions (name, description, comments, created_at) VALUES(%(name)s, %(description)s, %(comments)s, NOW() );"
        # create into deletions table for retrieving
        result = connectToMySQL("shop_db").query_db(save, data)
        # then delete from items table
        query = "DELETE FROM items WHERE id = %(item_id)s"
        confirm = connectToMySQL('shop_db').query_db(query, data)
        return result