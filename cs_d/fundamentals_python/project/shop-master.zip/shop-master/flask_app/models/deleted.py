from flask_app.config.mysqlconnection import connectToMySQL

class Deleted:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.description = data['description']
        self.comments = data['comments']
        self.created_at = data['created_at']

    # View all deleted items | works in dashboard page
    @classmethod
    def all_deletions(cls):
        query = "SELECT * from deletions"
        results = connectToMySQL('shop_db').query_db(query)
        return results
    
    # Store one deleted items values | 
    @classmethod
    def get_one_deleted(cls, data):
        query = "SELECT * FROM deletions WHERE id = %(item_id)s;"
        results = connectToMySQL('shop_db').query_db(query, data)
        return cls(results[0])

    # Delete item, used after restoration of item
    @classmethod
    def final_delete(cls, data):
        query = "DELETE FROM deletions WHERE id = %(item_id)s"
        result = connectToMySQL('shop_db').query_db(query, data)
        return result