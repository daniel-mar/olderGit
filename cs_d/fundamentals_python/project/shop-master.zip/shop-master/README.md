# Basic CRUD Functionality. Application
- Create inventory items
- Edit Them
- Delete Them
- View a list of them
Selected Feature
- When deleting, allow deletion comments and undeletion

# Included: requirements.txt, MySQL workbench ERD for forward engineering the schema for the application.
## Begin by installing necessary Python modules
- Pipenv install -r requirements.txt
## Confirm installation via pipfile.
## Enter the development environment.
- Pipenv shell
## Run the server while within the shop folder directory. 
- Python server.py

### There are no validations or authentications per the project requirements.
