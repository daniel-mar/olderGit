# recipes

### Practicing Fullstack development of CRUD & modularization with one to many relationships.
- A like button that updates depending if the user liked a recipe or not.
- Expand on bootstrap and using custom CSS within static folder for backgrounds and shadows.

A part of my continued growth in development, I want to continue to make projects and become comfortable with being stuck and working through debugging.
- I practice having the server terminal communicate where I am through the website, controllers, queries. 
- This allows me to have a better understanding of the programs process and the steps it when sending or receving & updating information dynamically.
