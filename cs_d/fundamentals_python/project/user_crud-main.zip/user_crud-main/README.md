# user_crud
## Languages: HTML, Bootstrap, Python, Jinja &amp; custom CSS

#### Summarized steps from start to finish
- Created the user diagram in MySQL workbench
- Forward engineered and populate the table.
- Installed dependencies and then created the server.
- Modularized and connect the files to each other.
- Created the Models & Routing.
- Developed each webpage while connecting to the database.
- Debugging the queries, jinja outputs, input test users.
- Add Bootstrap then custom styling

### Demo: Demo of the create read update and destroy process.
#### You are able to add a new user, update them and remove them from the database

![Alt Text](https://github.com/daniel-mar/user_crud/blob/main/demo_users_crud.gif)
