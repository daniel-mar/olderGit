from flask import Flask, render_template, request, redirect
from flask_app import app
from flask_app.models.user import User


@app.route('/')
def index():
    return redirect("/users")


@app.route("/users")
def users():
    users = User.get_all()
    return render_template("users.html", all_users=users)

# When you want to create a new user, redirect to html page
@app.route("/new")
def new():
    return render_template("new.html")

# after you click  on new users, you are brought here to a form
# Informtion from the form for new user, then is sent to the default '/users' show all users
# fixed issue, was from query inside of the user model! Successfully adds a user now & shows in table
@app.route("/users/new", methods=['POST'])
def add():
    User.add_user(request.form)
    return redirect("/users")

# Shows the user's information that you selected
@app.route("/users/show/<int:id>")
def view(id):
    data = {
        "id": id
    }
    user = User.show_user(data)
    return render_template("show.html", user=user)

# When you edit, it collected which user you clicked, places you as that user to edit.
@app.route("/users/edit/<int:id>")
def edit(id):
    data = {
        "id": id
        
    }
    user = User.show_user(data)
    return render_template("edit.html", user=user)

# What you submit when you edit the user wil get posted and used to query
# My plan to build this out more efficient is not use value inputs
# to auto populate the inputs when updating, but to use a for loop
# in order to check the keys & values from the table and query what was
# passsed inside the request.form
@app.route('/users/update', methods=['POST'])
def update():
    print('we have receeived the post information******')
    print(request.form)

    User.edit_user(request.form)
    return redirect("/users")

# DELETE.. CONSIDER: doing a warning before you want to delete
@app.route('/users/delete/<int:id>')
def delete(id):
    data = {
        "id": id
    }
    User.delete_user(data)
    return redirect("/user")
