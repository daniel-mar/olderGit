from flask_app.config.mysqlconnection import connectToMySQL

class User:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']


    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM users;"
        result = connectToMySQL('users_schema').query_db(query)
        users = []
        for item in result:
            users.append(cls(item))
        return users

# WE ARE ABLE TO ADD A USER NOW, needed to double check spelling & format
# adjusted the format of add_user, for inserting
    @classmethod
    def add_user(cls, data):
        query = "INSERT INTO users (first_name, last_name, email, created_at, updated_at) VALUES( %(add_fname)s, %(add_lname)s, %(add_email)s, NOW(), NOW() );"
        result = connectToMySQL('users_schema').query_db(query, data)
        return result


# WORKS, FIRST THING TO DO AND GET EVERYTHING FROM DATABASE
    @classmethod
    def show_user(cls, data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        result = connectToMySQL('users_schema').query_db(query, data)
        return cls(result[0])


# Working, the fix was the dictionary, but also commented in is another fix
    @classmethod
    def edit_user(cls, data):
        # capture the data, find the keys, start the query at the beginning
        # q = update users set
        # use a for loop to iterate through your object
        # inside the loop you will use whatever was pushed from the
        # user update and then use that for the for loop, to dynamically update
        # all of the queries.
        query = "UPDATE users SET first_name = %(add_fname)s, last_name = %(add_lname)s, email = %(add_email)s, updated_at = NOW() WHERE id = %(id)s;"

        result = connectToMySQL('users_schema').query_db(query, data)

        return result

# Working, CONFIRMED WITH DATABASE, can continue
    @classmethod
    def delete_user(cls, data):
        query = "DELETE FROM users WHERE id = %(id)s;"
        result = connectToMySQL('users_schema').query_db(query, data)
        return result
