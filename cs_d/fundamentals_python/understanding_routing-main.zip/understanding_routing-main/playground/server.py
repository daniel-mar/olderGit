from flask import Flask, render_template, redirect, session, request

app = Flask(__name__) # creates an instance utilizing the Flask framework and store it as 'app'

# SECOND CHUNK
# create your routes below
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/play')
def play():
    return render_template('index.html', x = 3, color = 'lightblue' )

@app.route('/play/<int:x>/<color>')
def number_of_boxes(x, color):
    return render_template('index.html', x = x, color = color)


# FINAL CHUNK for server; if statement to allow the server to run
if __name__ == "__main__":
    app.run(debug=True)