# IMPORT FLASK FRAMEWORK

from flask import Flask  # Import Flask to allow us to create our app

# ESTABLISH AN INSTANCE OF FLASK CLASS CALLED 'APP'
app = Flask(__name__)    # Create a new instance of the Flask class called "app"


# MIDDLE CHUNK, ROUTING FILES
# 1. have it say 'Hello World!'
@app.route('/')          # The "@" decorator associates this route with the function immediately following
def hello_world():
    return 'Hello World!'  # Return the string 'Hello World!' as a response

# 2. have it say 'Dojo
@app.route('/dojo')
def dojo():
    return 'Dojo!'



# 3. Create one url pattern and function that shows hello to different people
# - say Flask
@app.route('/say/flask')
def say_flask():
    return 'Flask is here'

# - say Michael
@app.route('/say/Michael')
def say_Michael():
    return 'Hi Michael'

# - say Hi John!
@app.route('/say/John')
def say_John():
    return 'Hey there John'


# 4. Creating url patterns & functions to handle the follow

# LAYOUT FOR MATH *****************************************
# @app.route('/math/<int:num>')
# def do_math(num):
#     temp = []
#     for i in range(0, num+1, 1):
#         temp.append(i)
#     return f"{temp}"

# - A. say 'hello' 35 times
# We can do if statements within 1 to do all of the words and numbers in 1 url, but I will leave the first as is!
@app.route('/repeat/<int:num>/hello')
def do_math(num):
    temp = []
    for i in range(num):
        temp.append('Hello')
    return f"There are {i+1} of these words: {temp}"

# - say 'bye' 80 times 
@app.route('/repeat/<int:num>/bye')
def do_math_bye(num):
    temp = []
    for i in range(num):
        temp.append('Bye')
    return f"there are {i+1} of {temp}"

# - say 'dogs' 99 times
@app.route('/repeat/<int:num>/dogs')
def do_math_dogs(num):
    temp = []
    for i in range(num):
        temp.append('Dogs')
    return f"there are {i+1} of {temp}"

# BONUS ENSURE NAMES FROM 3RD TASK ARE STRING
    # errors out when no string, have not added the ensure string is passed
@app.route('/repeat/<int:num>/<string:word>')
def do_math_word(num, word):
    temp = []
    for i in range(num):
        temp.append({word})
    return f"there are {i+1} of {temp}"


# FINAL CHUNK TO RUN SERVER
if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True)    # Run the app in debug mode.

