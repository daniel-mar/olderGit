# understanding_routing

Practicing the different routing possibility with Flask
