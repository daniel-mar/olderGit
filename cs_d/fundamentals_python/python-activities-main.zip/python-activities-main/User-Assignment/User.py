class User:		# here's what we have so far
    # Creating an instance of User
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account_balance = 0

    # User Methods / Functionality   
 
    # adding the deposit method *** ADD MONEY TO USER.ACCOUNT_BALANCE
    def make_deposit(self, amount):	# takes an argument that is the amount of the deposit
        self.account_balance += amount	# the specific user's account increases by the amount of the value received

    # adding the withdrawal method *** Subtract money from user.account_balance
    def make_withdrawal(self, amount):
        # If money will not be negative, proceed with the transaction
        if((self.get_user_balance() - amount) > 0):
            self.account_balance -= amount
        # else do not change account_balance
        else:
            print("error over withdraw limit")    

    # display the account balance, refers to string version of balance.
    def display_user_balance(self):
        if(self.account_balance > 0):
            print(self.account_balance)
        else:
            print("you have negative balance")    

    # getter, for the balance, to use in checks in other methods
    def get_user_balance(self):
        if(self.account_balance > 0):
            return self.account_balance
        else:
            print("error negative balance when getting")    

     # transfer money to another user
    def transfer_money(self, user, amount):
        self.make_withdrawal(amount)
        user.make_deposit(amount)

# Creating 3 instances of the User class
Daniel = User("Daniel", "someemail@gmail.com")
Sadia = User("Sadia", "sadiaemail@gmail.com")
Hamster = User("Ham", "hammiemail@gmail.com")

# First User makes 3 deposits, 1 withdrawal and display balance
Daniel.make_deposit(50)
Daniel.make_deposit(25)
Daniel.make_deposit(105)
Daniel.make_withdrawal(27)
Daniel.display_user_balance()

# Second user 2 deposits, 2 withdrawals and display balance
Sadia.make_deposit(25)
Sadia.make_deposit(74)
Sadia.make_withdrawal(10)
Sadia.make_withdrawal(20)
Sadia.display_user_balance()

# Third user 1 deposit, 3 withdrawls and display their balance
Hamster.make_deposit(1000)
Hamster.make_withdrawal(36)
Hamster.make_withdrawal(19)
Hamster.make_withdrawal(9)
Hamster.display_user_balance()

Hamster.transfer_money(Daniel, 300)
Hamster.display_user_balance()
Daniel.display_user_balance()