from flask_app.config.mysqlconnection import connectToMySQL
#create class with their class methods for querying and use throughout application
from flask import flash


# the ninja class to be used within dojos, remember dojos needs a list for
# the left joins information, when carrying each ninja from 1 dojo
class Ninja:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        
    @classmethod
    def add_ninja(cls,data):
        query = "INSERT INTO ninjas (first_name, last_name, age, dojo_id, created_at, updated_at) VALUES (%(first_name)s, %(last_name)s, %(age)s, %(dojo_id)s, NOW(), NOW());"
# connect to schema, don't store in db to read & understand the code steps better
        results = connectToMySQL('dojos_and_ninjas').query_db(query, data)

        return results
    
    @classmethod
    def get_one_with_ninjas(cls, data):
        query = "SELECT * FROM dojos LEFT JOIN ninjas on dojos.id = ninjas.dojo_id WHERE dojos.id = %(id)s;"
        
        results = connectToMySQL('dojos_and_ninjas').query_db(query,data)
        
        dojo = cls(results[0])
        
        for row in results:
            x = {
                'id': row['ninjas.id'],
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                'age': row['age'],
                'created_at': row['ninjas.created_at'],
                'updated_at': row['ninjas.updated_at']
            }

            dojo.ninjas.append( Ninja(x) )
        return dojo

    @staticmethod
    def validate_ninja(ninja):
        is_Valid = True
        first = (ninja['first_name'])
        size_first = len(first)
        print(size_first)
        last = (ninja['last_name'])
        size_last = len(last)

        if len(ninja['age']) <= 1 and size_first <= 1 and size_last <= 1:
            flash('Fields must be at least 2 characters')
            is_Valid = False
        return is_Valid