from flask_app.config.mysqlconnection import connectToMySQL
# is this the correct file structure to add into here?
from .ninja import Ninja
# should validating the userid be included in dojo?
from flask import flash

# reminder, include list inside of here for left join 
# query results to be stored for the ninjas
class Dojo:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = []

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM dojos;"

        results = connectToMySQL('dojos_and_ninjas').query_db(query)
        dojos = []

        for item in results:
            dojos.append(cls(item))
        return dojos

    @classmethod
    def create_dojo(cls, data):
        query = "INSERT INTO dojos (name, created_at, updated_at) VALUES (%(new_dojo)s, NOW(), NOW());"

        results = connectToMySQL('dojos_and_ninjas').query_db(query, data)

        return results
    
    @classmethod
    def get_one_with_ninjas(cls, data ):
        query = "SELECT * FROM dojos LEFT JOIN ninjas on dojos.id = ninjas.dojo_id WHERE dojos.id = %(id)s;"
        
        results = connectToMySQL('dojos_and_ninjas').query_db(query,data)
        
        dojo = cls(results[0])
        
        for row in results:
            x = {
                'id': row['ninjas.id'],
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                'age': row['age'],
                'created_at': row['ninjas.created_at'],
                'updated_at': row['ninjas.updated_at']
            }
            
            dojo.ninjas.append(Ninja(x))
        return dojo
    
    @staticmethod
    def validate_dojo(dojo):
        is_Valid = True
        if len(dojo['new_dojo']) < 3:
            flash('Name must be at least 3 characters')
            is_Valid = False
        return is_Valid