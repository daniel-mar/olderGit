from flask_app import app
from flask import render_template, redirect, request, session
# is the following needed? check
from flask_app.models.dojo import Dojo

# I want to redirect to / after the POST methods
# I am assuming the user would want to return to see the dojo page
# After I will redirect them to the /dojos and query database
# experiment storing routes in variables to place them inside of form actions

@app.route('/')
def index():
    return redirect ('/dojos')

@app.route('/dojos')
def dojos():
    dojos = Dojo.get_all()
    return render_template('dojos.html', all_dojos = dojos)

    #validate, follow this to models.dojo
@app.route('/new_dojo', methods=['POST'])
def new_dojo():
    if not Dojo.validate_dojo(request.form):
        return redirect ('/')
    
    Dojo.create_dojo(request.form)
    return redirect('/dojos')

@app.route('/dojo/<int:id>')
def show_dojo(id):
    data = {
        "id": id
    }
    dojo = Dojo.get_one_with_ninjas(data)
    return render_template('dojo_info.html', dojo = dojo)