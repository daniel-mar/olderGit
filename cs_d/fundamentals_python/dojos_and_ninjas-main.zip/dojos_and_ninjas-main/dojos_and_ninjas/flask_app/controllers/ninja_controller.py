from flask_app import app
from flask import render_template, redirect, request, session

# import models later.. the following are the models needed to be accessed
from flask_app.models import dojo, ninja
from flask_app.models.ninja import Ninja

@app.route('/ninjas')
def ninjas():
    dojos = dojo.Dojo.get_all()
    return render_template('new_ninja.html', dojos = dojos)

@app.route('/new_ninja', methods=['POST'])
def new_ninja():
    if not Ninja.validate_ninja(request.form):
        return redirect('/ninjas')

    ninja.Ninja.add_ninja(request.form)
    return redirect('/ninjas')