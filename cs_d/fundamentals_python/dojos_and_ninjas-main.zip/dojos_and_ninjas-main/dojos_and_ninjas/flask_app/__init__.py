from flask import Flask

app = Flask(__name__)
app.secret_key = "sakldad91u3hn1ju12hklj1"