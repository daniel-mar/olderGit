# dojos_and_ninjas - video demo 
### Included creating a new dojo and adding a ninja to that dojo. 
### Dynamically create links from the table dataset with jinja as well as user input checks. 
Practicing querying one to many relationships!
- Project from ERD to Full Stack
- Create Dojos that house many ninjas, which we want to display with queries.
- Considered how the dojos would be holding the ninjas by LEFT JOIN querying.
- I decided to add a few valid checks that redirect the user when the form contains empty characters.
- I want to practice adding delete and update methods per table. As well as using jinja to store the form ACTION urls to prevent plain text XSS.


![Alt Text](https://github.com/daniel-mar/dojos_and_ninjas/blob/main/dojos_and_ninjas.gif)
