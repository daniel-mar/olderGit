from flask_app import app
# controllers (this project requires two)
from flask_app.controllers import dojo_controller, ninja_controller



if __name__ == "__main__":
    app.run(debug=True)