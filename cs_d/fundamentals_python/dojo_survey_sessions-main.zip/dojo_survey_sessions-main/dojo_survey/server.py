from flask import Flask, render_template, redirect, session, request

app = Flask(__name__) # creates an instance utilizing the Flask framework and store it as 'app'
app.secret_key = "12j3k2121i1m78k6"

# SECOND CHUNK
# create your routes below
@app.route('/')
def index():
    # when the user posts data and a session is made to store their information
    # we create a user object with the new data and render index.html with data
    if "name" in session:
        user = {
            "name" : session['name'],
            "location" : session['location'],
            "language" : session['language'],
            "comments" : session['comments']
        }
        print(user)
        return render_template("result.html", user_template = user)
    else:
        return render_template('index.html')

@app.route('/processing', methods=["post"])
def processUser():
    print(request.form)

    # for sensei practice, check for if user selected a radio button or checkbox,
    # if not, redirect to main website
    # if they did, proceed to current code that redirects user input
    # the project is finished, the rest if for the bonuses & practice


    session["name"] = request.form['name']
    session["location"] = request.form['location']
    session["language"] = request.form['language']
    session["comments"] = request.form['comments']
    return redirect('/')

@app.route('/reset', methods=["post"])
def removeU():
    session.clear()
    return redirect('/')


# FINAL CHUNK for server; if statement to allow the server to run
if __name__ == "__main__":
    app.run(debug=True)