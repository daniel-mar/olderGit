# dojo_survey_sessions

requires updating of output stylings, as well as new inputs for extra practice.

complete that allows for inputting data and storing in order to output to the user in another page. Correctly redirecting to another page and introducing conditions in order to laod a page with data if a session exists. 
