-- 1 Completed; don't mind the formating, I tried the 'beautify formatting' from edit
SELECT 
    countries.name,
    countrylanguage.Language,
    countrylanguage.Percentage
FROM
    world.countries
        JOIN
    world.countrylanguage ON countries.code = countrylanguage.CountryCode
WHERE
    countrylanguage.Language = 'Slovene'
ORDER BY countrylanguage.Percentage DESC; -- order by column name in descending

-- 2 Completed
SELECT countries.Name, -- select Countries name
count(cities.id)
FROM world.countries -- from database named 'world', table named 'country'
LEFT JOIN world.cities -- table 2
ON countries.code = cities.country_code -- table 1 column name = table 2 column name
GROUP BY cities.country_code
ORDER BY count(cities.id) desc;

-- 2 rewritten: completed
SELECT world.countries.name, COUNT(world.cities.country_code)
FROM world.countries
LEFT JOIN world.cities
ON countries.code = world.cities.country_code
GROUP BY world.cities.country_code;

-- 3 
-- todo: output: 36 or 37, expected 27
SELECT cities.name, cities.population, country_id
FROM world.cities
LEFT JOIN world.countries
ON cities.country_id = countries.id
WHERE cities.population > 500000 && country_id = 136
order by cities.population desc;

-- 3, attempt 2; correct rows
SELECT cities.name, cities.population, cities.country_id
FROM cities
LEFT JOIN countries
ON cities.country_code = code
WHERE country_id = 136 && cities.population > 500000
;

-- 4
-- todo: expected is 81, 40 returned, suspect I am not reaching full information via syntax
SELECT countries.name,
countrylanguage.Language,
countrylanguage.Percentage -- select names of country from countries (1st table) & language + percentages from countrylanguage (2nd table)
FROM world.countries
JOIN world.countrylanguage -- 2nd table
ON countries.code = countrylanguage.CountryCode -- table 1 column name = table 2 column name
WHERE countrylanguage.Percentage > 89 -- matching table 2.column name
order by countrylanguage.Percentage desc;

-- 4, attempt 2; completed
SELECT countries.name,
countrylanguage.Language,
countrylanguage.Percentage
FROM world.countries
LEFT JOIN countrylanguage
ON countries.code = countrylanguage.CountryCode
WHERE countrylanguage.Percentage > 89
;

-- 5 Completed
SELECT countries.name, countries.surface_area, countries.population
FROM world.countries
WHERE countries.surface_area < 501 && countries.Population > 100000;

-- 6 Completed
-- Expected 13, got 12, Netherlands is new value. Fits criteria still.
SELECT countries.name,
countries.government_form,
countries.capital,
countries.life_expectancy
FROM world.countries
WHERE countries.government_form = 'Constitutional Monarchy' && countries.life_expectancy > 75;

-- 7 Completed
-- maybe better way to lay out where clause?
SELECT countries.name,
	cities.name,
	cities.district,
	cities.population
FROM world.cities
LEFT JOIN world.countries
ON cities.country_code = countries.code
WHERE countries.name = 'Argentina'
	&& cities.district = 'Buenos Aires'
	&& cities.population > 500000;

-- 8 Completed
SELECT COUNT(countries.id),
countries.region
FROM world.countries
GROUP BY countries.region
ORDER BY count(countries.id) desc