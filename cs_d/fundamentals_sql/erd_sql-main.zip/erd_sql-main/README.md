# ERDs and SQL
## A collection of databases, ERD & SQL Syntax for any activities. Will attempt to include assignment details if any.

![alt text](https://github.com/daniel-mar/erd_sql/blob/main/dojos_and_ninjas/erd/dojos_and_ninjas.PNG)
