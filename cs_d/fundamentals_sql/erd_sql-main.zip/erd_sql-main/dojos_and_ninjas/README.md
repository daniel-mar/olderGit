# Dojos and Ninjas!
Populate 2 tables, create 3 dojos, remove 3 dojos, create 3 more dojos, create 3 ninjas per dojo. 


Query: display ninjas belonging to specific dojos.


![alt text](https://github.com/daniel-mar/erd_sql/blob/main/dojos_and_ninjas/erd/dojos_and_ninjas.PNG)
