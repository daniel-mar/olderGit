-- INSERT 3 NEW DOJOS  
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('NYC Dojo', now(), now());
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('NYC Dojo', now(), now());
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('NYC Dojo', now(), now());

-- check if data popualted the database with SELECT
SELECT * FROM mydb.dojos;

-- Delete the 3 dojos you created
DELETE FROM mydb.dojos
WHERE id = 4;
DELETE FROM mydb.dojos
WHERE id = 2;
DELETE FROM mydb.dojos
WHERE id = 3;

-- Create 3 more dojos
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('NYC Dojo', now(), now());
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('LA Dojo', now(), now());
INSERT INTO mydb.dojos (dojo_name, created_at, updated_at)
VALUES('Boulder Dojo', now(), now());

-- Create 3 ninjas, belonging to the 3 dojos
INSERT INTO mydb.ninjas (id, first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Daniel', 'Martinez', 28, 5, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Nancy', 'Drew', 27, 5, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Jeff', 'Mehname', 24, 5, now(), now());
-- SECOND SET OF NINJAS
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Dave', 'Mario', 29, 6, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Velvet', 'Drewberry', 30, 6, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Turle', 'Straws', 24, 6, now(), now());
-- THIRD SET OF NINJAS
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Dave', 'Arnold', 24, 7, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Crust', 'Bumblebee', 30, 7, now(), now());
INSERT INTO mydb.ninjas (first_name, last_name, age, dojo_id, created_at, updated_at)
VALUES('Tits', 'Mcgee', 24, 7, now(), now());

-- Check if ninjas is populated with new data
SELECT * FROM mydb.ninjas;

-- INNER JOIN or JOIN of both tables
SELECT * FROM mydb.ninjas
JOIN mydb.dojos ON dojo_id = ninjas.dojo_id;

-- Retieve Data of ninjas that belong to the first dojo listed
SELECT * -- select all
FROM mydb.ninjas -- table you want to see information
LEFT JOIN mydb.dojos -- the many relationship, dojo holds many ninjas
ON mydb.dojos.id = mydb.ninjas.dojo_id
WHERE dojo_id = 5; -- dojos table by id = ninjas table by dojo_id foreign key

-- Retrieve Data of ninjas who go to second dojo listed(6)
SELECT *
FROM mydb.ninjas
LEFT JOIN mydb.dojos
ON mydb.dojos.id = mydb.ninjas.dojo_id
WHERE dojo_id = 6; -- must specify the foreign key, from ninjas)

-- Retrieve Data of ninjas who go to third dojo listed(7)
SELECT *
FROM mydb.ninjas
LEFT JOIN mydb.dojos
ON mydb.dojos.id = mydb.ninjas.dojo_id
WHERE dojo_id = 7; -- must specify the foreign key, from ninjas)

