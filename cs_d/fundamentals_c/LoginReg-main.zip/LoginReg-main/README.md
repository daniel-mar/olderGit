# LoginReg
C# Practicing Login Registrations, Validations
