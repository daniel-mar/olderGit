using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LoginReg
{
    public class User
    {
        [Key]
        public int UserId {get;set;}

        [Required]
        public string fname {get;set;}
        
        [Required]
        public string lname {get;set;}

        [Required]
        [EmailAddress]
        // email pattern is A-Z0-9@A-Z0-9.com/net(A-Z)
        public string email {get;set;}

        [Required]
        [DataType(DataType.Password)]
        public string password {get;set;}

        public DateTime CreatedAt {get;set;} = DateTime.Now;
        public DateTime UpdatedAt {get;set;} = DateTime.Now;

        // These are what I don't want save to my database
        [NotMapped]
        [DataType(DataType.Password)]
        [Compare("password")]
        public string confirm {get;set;}
    }
}