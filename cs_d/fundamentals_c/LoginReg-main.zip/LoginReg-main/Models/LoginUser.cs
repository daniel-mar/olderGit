using System;
using System.ComponentModel.DataAnnotations;

namespace LoginReg.Models
{
    public class LoginUser
    {
        [Required]
        [EmailAddress]
        public string lemail { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string lpassword { get; set; }
    }
}