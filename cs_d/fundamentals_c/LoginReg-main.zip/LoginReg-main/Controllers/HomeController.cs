﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using LoginReg.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

// MUST COMPLETE

namespace LoginReg.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private MyContext _context;

        public HomeController(ILogger<HomeController> logger, MyContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // Register New User
        [HttpPost("register")]
        public IActionResult Register(User newUser)
        {
            if(ModelState.IsValid)
            {
                // Check if the email exists in the DB (Users)
                if(_context.Users.Any(user => user.email == newUser.email))
                {
                    ModelState.AddModelError("email", "Email already exists");
                    return View("Index");
                }
                // Hash the password after verifying that everything else is good to go
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                newUser.password = Hasher.HashPassword(newUser, newUser.password);
                
                // adding to database and updating
                _context.Add(newUser);
                _context.SaveChanges();
                return RedirectToAction("Success");
            } else {
                return View("Index");
            }
        }

        [HttpGet("SignIn")]
        public IActionResult SignIn()
        {
            return View();
        }

        // successful user creation
        [HttpGet("Success")]
        public IActionResult Success()
        {
            return View();
        }

        // login route
        [HttpPost("login")]
        public IActionResult Login(LoginUser LoginUser) {
            if(ModelState.IsValid)
            {
                // Query user in db
                User userInDb = _context.Users.FirstOrDefault(user => user.email == LoginUser.lemail);
                if(userInDb == null)
                {
                    ModelState.AddModelError("lemail", "Invalid login attempt");
                    return View("SignIn");
                }
                // Password check
                PasswordHasher<LoginUser> Hasher = new PasswordHasher<LoginUser>();
                // var = db password, submitted password
                PasswordVerificationResult result = Hasher.VerifyHashedPassword(LoginUser, userInDb.password, LoginUser.lpassword);
                // Verification runs, returns 1 or 0. 1 = successful, 0 = unsuccessful
                if(result == 0)
                {
                    // The password was wrong
                    ModelState.AddModelError("lemail", "Inavlid login attempt");
                    return View("SignIn");
                }
                return RedirectToAction("Success");
            } else{
                return View("SignIn");
            }
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
