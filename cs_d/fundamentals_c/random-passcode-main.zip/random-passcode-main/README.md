# random-passcode
C#, generate a random passcode.
