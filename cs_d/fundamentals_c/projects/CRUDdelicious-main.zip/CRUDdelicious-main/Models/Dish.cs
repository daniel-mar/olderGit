using System;
using System.ComponentModel.DataAnnotations;

namespace cruDelicious.Models
{
    public class Dish
    {
        [Key]
        public int DishId { get; set; }

        [Required]
        // [Display(Name = "Chef's Name")]
        public string ChefName { get; set; }

        [Required]
        public string DishName { get; set; }

        [Required]
        [Range(0,3600)]
        public int Calories { get; set; }

        [Required]
        public int Tastiness { get; set; }

        [Required]
        public string Description { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
    }
}