﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using cruDelicious.Models;
using Microsoft.EntityFrameworkCore;

namespace cruDelicious.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private MyContext _context;

        public HomeController(ILogger<HomeController> logger, MyContext context)
        {
            _logger = logger;
            _context = context;

        }

        [HttpGet("")]
        public IActionResult Index()
        {
            // List of Dishes to output on Dashboard or Index.cshtml
            List<Dish> AllDishes = _context.Dishes.OrderByDescending(dish => dish.CreatedAt).ToList();
            ViewBag.AllDishes = AllDishes;
            return View(AllDishes);
        }

        // Click the add a new dish
        [HttpGet("/new")]
        public IActionResult New()
        {
            return View();
        }

        // CREATING A NEW DISH / DATABASE

        [HttpPost("Create")]
        public IActionResult Create(Dish newDish)
        {
            Console.WriteLine($"{newDish}");

            if(ModelState.IsValid)
            {
                Console.WriteLine("=== Valid");
                _context.Add(newDish);
                _context.SaveChanges();
                return RedirectToAction("Index");
            } else {
                Console.WriteLine("Invalid ===");
                return View("New");
            }
        }

        // Viewing the clicked single dish
        [HttpGet("{dishId}")]
        public IActionResult Dish(int dishId)
        {
            Dish singleDish = _context.Dishes.SingleOrDefault(dish => dish.DishId == dishId);
            return View("Dish", singleDish);
        }

        // Edit the clicked single dish within viewing the dish
        [HttpGet("edit/{dishId}")]
        public IActionResult Edit(int dishId)
        {
            Dish singleDish = _context.Dishes.SingleOrDefault(dish => dish.DishId == dishId);

            return View("Edit", singleDish);
        }

        // Update the selected dish
        [HttpPost("Update/{dishId}")]
        public IActionResult Update(int dishId, Dish editDish)
        {
            Console.WriteLine("inside of update");
            if(ModelState.IsValid)
            {
            Console.WriteLine("inside of valid");
                Dish singleDish = _context.Dishes.SingleOrDefault(dish => dish.DishId == dishId);

                singleDish.ChefName = editDish.ChefName;
                singleDish.DishName = editDish.DishName;
                singleDish.Calories = editDish.Calories;
                singleDish.Tastiness = editDish.Tastiness;
                singleDish.Description = editDish.Description;
                singleDish.UpdatedAt = DateTime.Now;

                _context.SaveChanges();

                return RedirectToAction("Index");
            } else {
            Console.WriteLine("not valid");
                return View("Edit");
            }
        }

        // Delete after clicking button
        [HttpGet("delete/{dishId}")]
        public IActionResult Delete(int dishId)
        {

            Dish deleteDish = _context.Dishes.SingleOrDefault(dish => dish.DishId == dishId);
            _context.Dishes.Remove(deleteDish);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
