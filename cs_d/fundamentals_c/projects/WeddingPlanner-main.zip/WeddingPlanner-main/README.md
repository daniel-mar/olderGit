# WeddingPlanner

## Objectives
### Connect a Login/Registration to application that depends on a logged-in user
### Get practice building out your own database from wireframe
### Continued practice with many-to-many SQL tables/Entity Framework models (hint: this app will necessitate many-to-manys!)
### Create a web app that allows registered users to plan a wedding. Users can RSVP to weddings and view attendee lists.
