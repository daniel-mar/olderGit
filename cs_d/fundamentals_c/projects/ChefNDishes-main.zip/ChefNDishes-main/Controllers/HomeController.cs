﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ChefNDishes.Models;

// Added
using Microsoft.EntityFrameworkCore;

namespace ChefNDishes.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private MyContext _context;

        public HomeController(ILogger<HomeController> logger, MyContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            List<Chef> AllChefs = _context.Chefs.Include(chef => chef.CreatedDishes).OrderByDescending(chef => chef.CreatedAt).ToList();
            return View(AllChefs);
        }

        // Click Add Chef button from Landing Page
        [HttpGet("NewChef")]
        public IActionResult NewChef()
        {
            return View("NewChef");
        }

        // Click Submit from new/chef page
        [HttpPost("AddChef")]
        public IActionResult addChef(Chef newChef)
        {

            if(ModelState.IsValid)
            {
                // On Successful validation
                _context.Add(newChef);
                _context.SaveChanges();
                return RedirectToAction("Index");
            } else {
            // Unsuccessful 
            return View("NewChef");
            }
        }

        // Click on Dishes Link from Landing Page
        [HttpGet("Dishes")]
        public IActionResult Dishes()
        {
            ViewBag.AllChefs = _context.Chefs.Include(chef => chef.CreatedDishes).ToList();
            return View("Dishes");
        }

        // Clicked Add Dish button in Dishes Page
        [HttpGet("NewDish")]
        public IActionResult NewDish()
        {
            ViewBag.AllChefs = _context.Chefs.OrderBy(chef => chef.FirstName).ToList();
            return View("NewDish");
        }

        [HttpPost("AddDish")]
        public IActionResult AddDish(Dish newDish)
        {
            if(ModelState.IsValid)
            {
                // On Successful validation
                _context.Add(newDish);
                _context.SaveChanges();
                return RedirectToAction("Index");
            } else {
            // Unsuccessful | REMEMBER TO REDO THE VIEWBAG FOR THE UNSUCCESSFUL
            ViewBag.AllChefs = _context.Chefs.OrderBy(chef => chef.FirstName).ToList();
            return View("NewDish");
            }
        }


        // BONUS Pages ===========
        // Show Chef
        [HttpGet("chef/{ChefId}")]
        public IActionResult ShowChef(int ChefId)
        {
            Chef Chef = _context.Chefs.FirstOrDefault(chef => chef.ChefId == ChefId);
            return View("ShowChef", Chef);
        }

        // Show Dish
        [HttpGet("dish/{DishId}")]
        public IActionResult ShowDish(int DishId)
        {
            Dish Dish = _context.Dishes.FirstOrDefault(dish => dish.DishId == DishId);
            return View("ShowDish", Dish);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
