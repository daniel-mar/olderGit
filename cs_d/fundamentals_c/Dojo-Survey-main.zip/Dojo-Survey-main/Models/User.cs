using System;
// Validation
using System.ComponentModel.DataAnnotations;

namespace dojoSurvey.Models
{
    public class User
    {

        [Required(ErrorMessage = "Name please")]
        public string Name { get; set; }

        [Required]
        [MinLength(3, ErrorMessage = "City must be 3 characters in length")]
        public string City { get; set; }

        [Required]
        public string favLang { get; set; }

        // Does not let user type more than 20 characters
        [MaxLength(20)]
        public string Comment { get; set; }
    }
}