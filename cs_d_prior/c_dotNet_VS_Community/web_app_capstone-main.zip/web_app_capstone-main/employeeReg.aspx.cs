﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.DataModel;

namespace Final_Project
{
    public partial class employeeReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EmployeeInfo"] != null)
            {
                EmployeeInformation theEmployee = (EmployeeInformation)Session["EmployeeInfo"];

                txtFirstName.Text = theEmployee.first_name;
               
                txtLastName.Text = theEmployee.last_name;
                txtAddress.Text = theEmployee.home_address;
                txtAddress2.Text = theEmployee.home_address_two;
                txtEmailAddress.Text = theEmployee.email_address;
                txtDateofBirth.Text = theEmployee.date_of_birth.ToString();
                txtSSN.Text = theEmployee.ssn.ToString();
               

                Session["EmployeeInfo"] = null;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            EmployeeInformation theEmployee = new EmployeeInformation();
            int ssn;
            int date_of_birth;

            theEmployee.first_name = txtFirstName.Text;
            theEmployee.last_name = txtLastName.Text;
            theEmployee.home_address = txtAddress.Text;
            theEmployee.home_address_two = txtAddress2.Text;
            theEmployee.email_address = txtEmailAddress.Text;
            ssn = int.Parse(txtSSN.Text);
            theEmployee.ssn = ssn;
            date_of_birth = int.Parse(txtDateofBirth.Text);
            theEmployee.date_of_birth = date_of_birth;
            

            Session["EmployeeInfo"] = theEmployee;

            Response.Redirect("Confirmation.aspx");
        }
    }
}