﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.DataModel;
using Final_Project.DataAccessLayer;

namespace Final_Project.SiteAdmin
{
    public partial class EmployeeInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            EmployeeTier theTier = new EmployeeTier();
            List<EmployeeInformation> theList;
            Table theTable = new Table();
            TableRow tr = new TableRow();
            TableCell td;
            theList = theTier.getAllEmployees();
            Button delete;

            TableHeaderCell th = new TableHeaderCell();
            Label theLabel = new Label();
            theLabel.Text = "Employee ID";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "SSN";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "First Name";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Last Name";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Address";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Address2";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Date of Birth";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);


            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Email Address";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            th = new TableHeaderCell();
            theLabel = new Label();
            theLabel.Text = "Commands";
            th.Controls.Add(theLabel);
            tr.Cells.Add(th);

            theTable.Rows.Add(tr);

            foreach (EmployeeInformation Employee in theList)
            {
                tr = new TableRow();

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.employee_ID.ToString();
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.first_name;
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.last_name;
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.ssn.ToString();
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.home_address;
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.home_address_two;
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.date_of_birth.ToString();
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                theLabel = new Label();
                theLabel.Text = Employee.email_address.ToString();
                td.Controls.Add(theLabel);
                tr.Cells.Add(td);

                td = new TableCell();
                delete = new Button();
                delete.Text = "Delete";
                delete.ID = Employee.employee_ID.ToString();
                delete.Click += deleteClick;
                td.Controls.Add(delete);
                tr.Cells.Add(td);

                theTable.Rows.Add(tr);
            }
            pnlOut.Controls.Add(theTable);
        }

        protected void deleteClick(object sender, EventArgs e)
        {
            Button theButton = (Button)sender;
            EmployeeTier theTier = new EmployeeTier();
            int EmployeeID = int.Parse(theButton.ID);

            theTier.deleteEmployee(EmployeeID);

            Response.Redirect("employeeReg.aspx");
        }
    }
}