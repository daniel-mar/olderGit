# web_app_capstone
created using asp.net bootstrap.js c# mysql

The following is code snippets of how a project was built in the above mentioned technologies. I also have a similar updated project of a paintstore in a usb I misplaced. Which was simpler with less classes, more stream-line. I will post some of those images as well to show the similar functionality. The school database has been disconnected and cannot actually connect. This project earned a B+ as a final project grade, for the course of Web-Application Development and was also my grade in the database management course that I took simultaneously.

This project was difficult to grasp, it involved a lot of self teaching, and I owe my self-studying a lot of credit because it allowed me to take my small knowledge in Java after a Summer course and translate that into C# and grow it from there. With the help of documentation and forums, I was able to complete these projects. Practicing creating my own UML diagrams and then building out the databases in SQL was fun and I would like to explore that more in a professional level in a method that is more business standard, not on my own or academically (similar to on own at times).

What was a double edge sword for me (like and dislike) was bootstrap, the ease of creating projects but I couldn't make it my own without possibly running into issues with set stylings in bootstrap. I enjoy being able to customize a webpage, insert different javascript techniques for possible smooth transitions as well as customize the css more in creating a landing page and 1 page layouts. But the course was based around this and not necessarily the personalization of the website, we had to build out a three-tiered business application.

Overall, it was an interesting way to learn on my own, I couldn't really rely on the teacher even though they did show us a few examples and had plenty of times to ask questions, it was a work on your own by the concepts taught and make it your own from there. I am looking to learn something new in development because of that. An impactful project, where I can learn and apply what I learn into a project.


edit: specifying grades of project and courses.
