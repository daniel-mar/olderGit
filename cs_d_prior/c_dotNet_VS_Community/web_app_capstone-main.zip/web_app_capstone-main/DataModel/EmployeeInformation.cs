﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project.DataModel
{
    public class EmployeeInformation
    {
        public int employee_ID { get; set; }
        public int ssn { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email_address { get; set; }
        public string home_address { get; set; }
        public string home_address_two { get; set; }
        public int date_of_birth { get; set; }
    }
}