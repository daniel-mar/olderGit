﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project.DataModel
{
    public class inventoryInformation
    {
        public int gameID { get; set; }
        public string title { get; set; }
        public string genre { get; set; }
        public int rating { get; set; }
        public int price { get; set; }
        public int consoleid { get; set; }
        public int quantity { get; set; }

}
}