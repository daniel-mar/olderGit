﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Final_Project.DataModel
{
    public class aboutInformation
    {
        public int storeID { get; set; }
        public string store_name { get; set; }
        public string website { get; set; }
        public string email_address { get; set; }

    }
}