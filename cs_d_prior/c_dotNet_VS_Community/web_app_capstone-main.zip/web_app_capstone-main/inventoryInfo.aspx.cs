﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.DataModel;
using Final_Project.DataAccessLayer;

namespace Final_Project.SiteAdmin
{
    public partial class inventoryInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void lbInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["title"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtTitle")).Text;
            SqlDataSource1.InsertParameters["genre"].DefaultValue = ((DropDownList)GridView1.FooterRow.FindControl("ddlGenre")).SelectedValue;
            SqlDataSource1.InsertParameters["rating"].DefaultValue = ((DropDownList)GridView1.FooterRow.FindControl("ddlrating")).SelectedValue;
            SqlDataSource1.InsertParameters["price"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtPrice")).Text;
            SqlDataSource1.InsertParameters["consoleid"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtConsoleID")).Text;
            SqlDataSource1.InsertParameters["quantity"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("txtQuantity")).Text;

            SqlDataSource1.Insert();

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
