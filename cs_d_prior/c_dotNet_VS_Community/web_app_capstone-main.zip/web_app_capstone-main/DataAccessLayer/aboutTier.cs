﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using Final_Project.DataModel;

namespace Final_Project.DataAccessLayer
{
    public class aboutTier
    {
        public string connectionString { get; set; }

        public aboutTier()
        {
            connectionString = ConfigurationManager.ConnectionStrings["MyData"].ToString();
        }
        public List<aboutInformation> getAllAbout()
        {
            List<aboutInformation> theList = null;
            aboutInformation theAbout;
            string query = "SELECT * FROM aboutInformation;";
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataReader reader;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    theList = new List<aboutInformation>();
                    while (reader.Read())
                    {
                        theAbout = new aboutInformation();
                        theAbout.storeID = (int)reader["StoreID"];
                        theAbout.website = reader["Website"].ToString();
                        theAbout.email_address = reader["EmailAddress"].ToString();
                        theAbout.store_name = reader["StoreName"].ToString();
                        

                        theList.Add(theAbout);
                    }

                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return theList;
        }
    }
}