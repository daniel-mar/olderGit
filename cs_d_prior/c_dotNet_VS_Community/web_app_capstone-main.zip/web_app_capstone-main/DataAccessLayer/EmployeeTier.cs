﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using Final_Project.DataModel;

namespace Final_Project.DataAccessLayer
{
    public class EmployeeTier
    {
        public string connectionString { get; set; }

        public EmployeeTier()
        {
            connectionString = ConfigurationManager.ConnectionStrings["MyData"].ToString();
        }
        public List<EmployeeInformation> getAllEmployees()
        {
            List<EmployeeInformation> theList = null;
            EmployeeInformation theEmployee;
            string query = "SELECT * FROM EmployeeInformation;";
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataReader reader;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    theList = new List<EmployeeInformation>();
                    while (reader.Read())
                    {
                        theEmployee = new EmployeeInformation();
                        theEmployee.employee_ID = (int)reader["EmployeeID"];
                        theEmployee.ssn = (int)reader["SSN"];
                        theEmployee.first_name = reader["FirstName"].ToString();
                        theEmployee.last_name = reader["LastName"].ToString();
                        theEmployee.email_address = reader["EmailAddress"].ToString();
                        theEmployee.home_address = reader["Address"].ToString();
                        theEmployee.home_address_two = reader["Address2"].ToString();
                        theEmployee.date_of_birth = (int)reader["DateofBirth"];

                        theList.Add(theEmployee);
                    }
                   
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return theList;
        }

        public bool insertEmployee(EmployeeInformation theEmployee)
        {
            bool success = false;
            int rows;
            string query = "INSERT INTO EmployeeInformation (EmployeeID, SSN, FirstName, LastName, Address, Address2, DateofBirth, EmailAddress) VALUES (@Fname, @LName, @Address, @Address2, @DateofBirth, @EmailAddress);";
            SqlConnection conn;
            SqlCommand cmd;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@EmployeeID", SqlDbType.Int, 50).Value = theEmployee.employee_ID;
            cmd.Parameters.Add("@FName", SqlDbType.VarChar, 50).Value = theEmployee.first_name;
            cmd.Parameters.Add("@LName", SqlDbType.VarChar, 50).Value = theEmployee.last_name;
            cmd.Parameters.Add("@SSN", SqlDbType.Int, 50).Value = theEmployee.ssn;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar, 50).Value = theEmployee.home_address;
            cmd.Parameters.Add("@Address2", SqlDbType.VarChar, 50).Value = theEmployee.home_address_two;
            cmd.Parameters.Add("@DateofBirth", SqlDbType.Int, 50).Value = theEmployee.date_of_birth;
            cmd.Parameters.Add("@EmailAddress", SqlDbType.VarChar, 50).Value = theEmployee.email_address;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
        public bool updateCustomer(EmployeeInformation theEmployee)
        {
            bool success = false;
            int rows;
            string query = "UPDATE EmployeeInformation SET first_name=@FirstName, " +
                "last_name = @LastName, Address = @Address, " +
                "Address2 = @Address, DateofBirth = @DateofBirth, EmailAddress = @EmailAddress " +
                "WHERE EmployeeID = @ID;";
            SqlConnection conn;
            SqlCommand cmd;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = theEmployee.employee_ID;
            cmd.Parameters.Add("@FName", SqlDbType.VarChar, 50).Value = theEmployee.first_name;
            cmd.Parameters.Add("@LName", SqlDbType.VarChar, 50).Value = theEmployee.last_name;
            cmd.Parameters.Add("@Address", SqlDbType.VarChar, 50).Value = theEmployee.home_address;
            cmd.Parameters.Add("@Address2", SqlDbType.VarChar, 50).Value = theEmployee.home_address_two;
            cmd.Parameters.Add("@DateofBirth", SqlDbType.Int).Value = theEmployee.date_of_birth;
            cmd.Parameters.Add("@EmailAddress", SqlDbType.VarChar).Value = theEmployee.email_address;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
        public bool deleteEmployee(int EmployeeID)
        {
            int rows;
            bool success;
            string query = "DELETE FROM EmployeeInformation " +
                "WHERE EmployeeID = @ID;";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = EmployeeID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
    }
}
