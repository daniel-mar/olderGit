﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using Final_Project.DataModel;

namespace Final_Project.DataAccessLayer
{
    public class inventoryTier
    {
        public string connectionString { get; set; }

        public inventoryTier()
        {
            connectionString = ConfigurationManager.ConnectionStrings["MyData"].ToString();
        }
        public List<inventoryInformation> getAllInventory()
        {
            List<inventoryInformation> theList = null;
            inventoryInformation theInventory;
            string query = "SELECT * FROM inventoryInformation;";
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataReader reader;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    theList = new List<inventoryInformation>();
                    while (reader.Read())
                    {
                        theInventory = new inventoryInformation();
                        theInventory.gameID = (int)reader["GameID"];
                        theInventory.title = reader["Title"].ToString();
                        theInventory.genre = reader["Genre"].ToString();
                        theInventory.rating = (int)reader["Rating"];
                        theInventory.price = (int)reader["Price"];
                        theInventory.consoleid = (int)reader["ConsoleID"];
                        theInventory.quantity = (int)reader["Quantity"];

                        theList.Add(theInventory);
                    }

                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return theList;
        }
        public bool insertInventory(inventoryInformation theInventory)
        {
            bool success = false;
            int rows;
            string query = "INSERT INTO inventoryInformation (gameID, title, genre, rating, price, consoleid, quantity) VALUES (@gameID, @title, @genre, @rating, @price, @consoleid, @quantity);";
            SqlConnection conn;
            SqlCommand cmd;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@gameID", SqlDbType.Int,50).Value = theInventory.gameID;
            cmd.Parameters.Add("@title", SqlDbType.VarChar,50).Value = theInventory.title;
            cmd.Parameters.Add("@genre", SqlDbType.VarChar,50).Value = theInventory.genre;
            cmd.Parameters.Add("@rating", SqlDbType.Int,50).Value = theInventory.gameID;
            cmd.Parameters.Add("@price", SqlDbType.Int, 50).Value = theInventory.price;
            cmd.Parameters.Add("@consoleid", SqlDbType.Int, 50).Value = theInventory.consoleid;
            cmd.Parameters.Add("@quantity", SqlDbType.Int, 50).Value = theInventory.quantity;
            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
        public bool updateInventory(inventoryInformation theInventory)
        {
            bool success = false;
            int rows;
            string query = "UPDATE inventoryInformation SET title=@title, " +
                "genre= @genre, rating= @rating, " +
                "price= @price, consoleid= @consoleid" +
                "WHERE gameID = @ID;";
            SqlConnection conn;
            SqlCommand cmd;

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = theInventory.gameID;
            cmd.Parameters.Add("@title", SqlDbType.VarChar, 50).Value = theInventory.title;
            cmd.Parameters.Add("@genre", SqlDbType.VarChar, 50).Value = theInventory.genre;
            cmd.Parameters.Add("@rating", SqlDbType.VarChar, 50).Value = theInventory.rating;
            cmd.Parameters.Add("@price", SqlDbType.VarChar, 50).Value = theInventory.price;
            cmd.Parameters.Add("@consoleid", SqlDbType.Int).Value = theInventory.consoleid;
            cmd.Parameters.Add("@quantity", SqlDbType.VarChar).Value = theInventory.quantity;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
        public bool deleteInventory(int gameID)
        {
            int rows;
            bool success;
            string query = "DELETE FROM inventoryInformation " +
                "WHERE gameID = @ID;";
            SqlConnection conn = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = gameID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();

                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }
    }
}
