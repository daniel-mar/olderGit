﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Final_Project.DataModel;
using Final_Project.DataAccessLayer;

namespace Final_Project
{
    public partial class Confirmation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EmployeeInfo"] != null)
            {
                EmployeeInformation theEmployee = (EmployeeInformation)Session["EmployeeInfo"];

                lblFirstName.Text = theEmployee.first_name;
                lblLastName.Text = theEmployee.last_name;
                lblAddress.Text = theEmployee.home_address;
                lblAddress2.Text = theEmployee.home_address_two;
                lblEmailAddress.Text = theEmployee.email_address;
                lblSSN.Text = theEmployee.ssn.ToString();
                lblDateofBirth.Text = theEmployee.date_of_birth.ToString();
            } else
            {
                Response.Redirect("Default.aspx");
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeReg.aspx");
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            if (Session["EmployeeInfo"] != null)
            {
                EmployeeTier theTier = new EmployeeTier();
                EmployeeInformation theEmployee = (EmployeeInformation)Session["CustomerInfo"];

                theTier.insertEmployee(theEmployee);

                Session["EmployeeInfo"] = null;
                Response.Redirect("SuccessfullSubmission.aspx");
            }

        }
    }
}