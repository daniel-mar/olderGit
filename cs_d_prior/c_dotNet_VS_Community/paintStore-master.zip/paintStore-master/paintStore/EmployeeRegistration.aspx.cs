﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using paintStore.DataModel;

namespace paintStore
{
  public partial class EmployeeRegistration : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (Session["EmployeeData"] != null)
      {
        Employee employee = (Employee)Session["EmployeeData"];

        txtFirstName.Text = employee.firstName;
        txtLastName.Text = employee.lastName;
        txtAddress.Text = employee.address;
        txtAddress2.Text = employee.address2;
        txtCity.Text = employee.city;
        txtState.Text = employee.state;
        txtZip.Text = employee.zip.ToString();
        txtPhoneNumber.Text = employee.phoneNumber;
        txtDateOfBirth.Text = employee.dateOfBirth;
        txtTaxID.Text = employee.taxID.ToString();
        txtStoreID.Text = employee.storeID.ToString();
        txtManagerID.Text = employee.managerID.ToString();
      }

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      Employee employee = new Employee();
      employee.firstName = txtFirstName.Text;
      employee.lastName = txtLastName.Text;
      employee.address = txtAddress.Text;
      employee.address2 = txtAddress2.Text;
      employee.city = txtCity.Text;
      employee.state = txtState.Text;
      employee.zip = int.Parse(txtZip.Text);
      employee.phoneNumber = txtPhoneNumber.Text;
      employee.dateOfBirth = txtDateOfBirth.Text;
      employee.taxID = int.Parse(txtTaxID.Text);
      employee.storeID = int.Parse(txtStoreID.Text);
      employee.managerID = int.Parse(txtManagerID.Text);

      Session["EmployeeData"] = employee;

      Response.Redirect("Confirmation.aspx");
    }
  }
}