﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using paintStore.DataModel;
using paintStore.DataAccessLayer;

namespace paintStore
{
  public partial class Confirmation : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      if (Session["EmployeeData"] != null)
      {
        Employee employee = (Employee)Session["EmployeeData"];

        lblFirstName.Text = employee.firstName;
        lblLastName.Text = employee.lastName;
        lblAddress.Text = employee.address;
        lblAddress2.Text = employee.address2;
        lblCity.Text = employee.city;
        lblState.Text = employee.state;
        lblZip.Text = employee.zip.ToString();
        lblPhoneNumber.Text = employee.phoneNumber;
        lblDateOfBirth.Text = employee.dateOfBirth;
        lblTaxID.Text = employee.taxID.ToString();
        lblStoreID.Text = employee.storeID.ToString();
        lblManagerID.Text = employee.managerID.ToString();
      } else
      {
        Response.Redirect("Default.aspx");
      }
    }

    protected void btnBack_Click(object sender, EventArgs e)
    {
      Response.Redirect("EmployeeRegistration.aspx");
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (Session["EmployeeData"] != null)
      {
        EmployeeTier employeeTier = new EmployeeTier();
        Employee employee = (Employee)Session["EmployeeData"];

        employeeTier.insertEmployee(employee);

        Session["EmployeeData"] = null;

        Response.Redirect("Completion.aspx");
      }
    }
  }
}