﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using paintStore.DataModel;

namespace paintStore.DataAccessLayer
{
  public class EmployeeTier
  {
    private string connectionString;

    public EmployeeTier()
    {
      connectionString = ConfigurationManager.ConnectionStrings["MyData"].ToString();
    }

    public List<Employee> getAllEmployees()
    {
      List<Employee> employeeList = null;
      Employee employee;
      string query;
      SqlConnection conn;
      SqlCommand cmd;
      SqlDataReader reader;

      query = "SELECT * FROM EmployeeInformation;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      try
      {
        conn.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
          employeeList = new List<Employee>();
          while (reader.Read())
          {
            employee = new Employee();
            employee.employeeID = (int)reader["EmployeeID"];
            employee.firstName = reader["FirstName"].ToString();
            employee.lastName = reader["LastName"].ToString();
            employee.address = reader["Address"].ToString();
            employee.address2 = reader["Address2"].ToString();
            employee.city = reader["City"].ToString();
            employee.state = reader["State"].ToString();
            employee.zip = (int)reader["Zip"];
            employee.phoneNumber = reader["PhoneNumber"].ToString();
            employee.dateOfBirth = reader["DateOfBirth"].ToString();
            employee.taxID = (int)reader["TaxID"];
            employee.storeID = (int)reader["StoreID"];
            employee.managerID = (int)reader["ManagerID"];

            employeeList.Add(employee);
          }
        }
      }catch(SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }
      return employeeList;
    }

    public bool insertEmployee(Employee theEmployee)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;

      query = "INSERT INTO EmployeeInformation " +
        "(FirstName, LastName, Address, Address2, City, State, Zip, PhoneNumber, DateOfBirth, TaxID, StoreID, ManagerID) " +
        "VALUES(@Fname, @LName, @Address, @Address2, @City, @State, @Zip, @PhoneNumber, @DateOfBirth, @TaxID, @StoreID, @ManagerID);";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@FName", SqlDbType.VarChar, 50).Value = theEmployee.firstName;
      cmd.Parameters.Add("@LName", SqlDbType.VarChar, 50).Value = theEmployee.lastName;
      cmd.Parameters.Add("@Address", SqlDbType.VarChar, 50).Value = theEmployee.address;
      cmd.Parameters.Add("@Address2", SqlDbType.VarChar, 50).Value = theEmployee.address2;
      cmd.Parameters.Add("@City", SqlDbType.VarChar, 50).Value = theEmployee.city;
      cmd.Parameters.Add("@State", SqlDbType.VarChar, 50).Value = theEmployee.state;
      cmd.Parameters.Add("@Zip", SqlDbType.VarChar, 50).Value = theEmployee.zip;
      cmd.Parameters.Add("@PhoneNumber", SqlDbType.VarChar, 50).Value = theEmployee.phoneNumber;
      cmd.Parameters.Add("@DateOfBirth", SqlDbType.VarChar, 50).Value = theEmployee.dateOfBirth;
      cmd.Parameters.Add("@TaxID", SqlDbType.Int).Value = theEmployee.taxID;
      cmd.Parameters.Add("@StoreID", SqlDbType.Int).Value = theEmployee.storeID;
      cmd.Parameters.Add("@ManagerID", SqlDbType.Int).Value = theEmployee.managerID;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();
        if (rows > 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }
      }catch(SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }
      return success;
    }

    public bool updateEmployee(Employee theEmployee)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;

      query = "UPDATE EmployeeInformation SET firstName=@FirstName, lastName=@LastName," +
        "Address=@Address, Address2=@Address2, City=@City, State=@State, Zip=@Zip, phoneNumber=@PhoneNumber " +
        "dateOfBirth=@DateOfBirth, taxID=@TaxID, storeID=@StoreID, managerID=@ManagerID " +
        "WHERE employeeID=@EmployeeID;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = theEmployee.employeeID;
      cmd.Parameters.Add("@FName", SqlDbType.VarChar, 50).Value = theEmployee.firstName;
      cmd.Parameters.Add("@LName", SqlDbType.VarChar, 50).Value = theEmployee.lastName;
      cmd.Parameters.Add("@Address", SqlDbType.VarChar, 50).Value = theEmployee.address;
      cmd.Parameters.Add("@Address2", SqlDbType.VarChar, 50).Value = theEmployee.address2;
      cmd.Parameters.Add("@City", SqlDbType.VarChar, 50).Value = theEmployee.city;
      cmd.Parameters.Add("@State", SqlDbType.VarChar, 50).Value = theEmployee.state;
      cmd.Parameters.Add("@Zip", SqlDbType.VarChar, 50).Value = theEmployee.zip;
      cmd.Parameters.Add("@PhoneNumber", SqlDbType.VarChar, 50).Value = theEmployee.phoneNumber;
      cmd.Parameters.Add("@DateOfBirth", SqlDbType.VarChar, 50).Value = theEmployee.dateOfBirth;
      cmd.Parameters.Add("@TaxID", SqlDbType.Int).Value = theEmployee.taxID;
      cmd.Parameters.Add("@StoreID", SqlDbType.Int).Value = theEmployee.storeID;
      cmd.Parameters.Add("@ManagerID", SqlDbType.Int).Value = theEmployee.managerID;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();
        if(rows > 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }
      }
      catch(SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }

      return success;
    }


    public bool deleteEmployee(int EmployeeID)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;



      query = "DELETE FROM EmployeeInformation " +
        "WHERE EmployeeID = @EmployeeID;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = EmployeeID;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();

        if(rows> 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }
        
      }catch(SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }

      return success;
    }
  }
}