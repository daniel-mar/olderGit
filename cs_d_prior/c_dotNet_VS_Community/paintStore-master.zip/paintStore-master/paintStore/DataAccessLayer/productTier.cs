﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;
using paintStore.DataModel;

namespace paintStore.DataAccessLayer
{
  public class productTier
  {

    public string connectionString { get; set; }

    public productTier()
    {
      connectionString = ConfigurationManager.ConnectionStrings["MyData"].ToString();
    }

    public List<Product> getAllProducts()
    {
      List<Product> productList = null;
      Product product;
      string query;
      SqlConnection conn;
      SqlCommand cmd;
      SqlDataReader reader;

      query = "SELECT * FROM Products;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      try
      {
        conn.Open();
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
          productList = new List<Product>();
          while (reader.Read())
          {
            product = new Product();
            product.productID = (int)reader["ProductID"];
            product.productName = reader["ProductName"].ToString();
            product.productDescription = reader["ProductDescription"].ToString();
            product.productPrice = (int)reader["ProductPrice"];
            product.productQuantity = (int)reader["ProductQuantity"];

            productList.Add(product);
          }
        }
      } catch (SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }
      return productList;
    }

    public bool insertProduct(Product product)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;

      query = "INSERT INTO Products " +
        "(ProductName, ProductDescription, ProductPrice, ProductQuantity) " +
        "VALUES(@ProductName, @ProductDescription, @ProductPrice, @ProductQuantity);";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 50).Value = product.productName;
      cmd.Parameters.Add("@ProductDescription", SqlDbType.VarChar, 50).Value = product.productDescription;
      cmd.Parameters.Add("@ProductPrice", SqlDbType.Int).Value = product.productPrice;
      cmd.Parameters.Add("@ProductQuantity", SqlDbType.Int).Value = product.productQuantity;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();
        if (rows > 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }
      } catch (SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }
      return success;
    }

    public bool updateProduct(Product product)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;

      query = "UPDATE Products SET productName=@ProductName, productDescription=@ProductDescription," +
        "productPrice=@ProductPrice, productQuantity=@ProductQuantity" +
        "WHERE productID=@ProductID;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 50).Value = product.productName;
      cmd.Parameters.Add("@ProductDescription", SqlDbType.VarChar, 50).Value = product.productDescription;
      cmd.Parameters.Add("@ProductPrice", SqlDbType.Int).Value = product.productPrice;
      cmd.Parameters.Add("@ProductQuantity", SqlDbType.Int).Value = product.productQuantity;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();
        if (rows > 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }
      }catch (SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }

      return success;
    }

    public bool deleteProduct(int ProductID)
    {
      SqlConnection conn;
      SqlCommand cmd;
      string query;
      bool success = false;
      int rows;

      query = "DELETE FROM Products " +
        "WHERE ProductID = @ProductID;";

      conn = new SqlConnection(connectionString);
      cmd = new SqlCommand(query, conn);

      cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = ProductID;

      try
      {
        conn.Open();
        rows = cmd.ExecuteNonQuery();

        if (rows > 0)
        {
          success = true;
        }
        else
        {
          success = false;
        }

      }
      catch (SqlException ex)
      {
        throw new Exception(ex.Message);
      }
      finally
      {
        conn.Close();
      }

      return success;
      }
    }
  }