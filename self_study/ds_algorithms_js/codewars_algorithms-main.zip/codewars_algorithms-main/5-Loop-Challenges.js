// Print odds 1-20 *************************
/* the following is to check output logic prior to proceeding
console.log(4 % 2 ); -- 0
console.log(5 % 2); -- 1 
*/

/* const numLimit = 20
for (let i = 1; i < numLimit; i++) {
    if(i % 2 == 1)
    console.log(i + " is an odd value!");   
} */


// Decreasing Multiples of 3 *****************
/* We want to count down from 100 to 0
Console.logging each value that is a multiple of 3
Multiple of 3 is the same thing as NUMBER % 3 == 0
After it console.logs decrement the value by 1 until it reaches 0
*/

/* for (let i = 100; i > 0; i--) {
    if(i % 3 == 0)
        console.log(i);
}
 */

// Print the Sequence ***********************
/* const sequence = [4,2.5,1,-0.5,-2,-3.5];
for (let i = 0; i < sequence.length; i++) {
    console.log(sequence[i]);
    
} */


// Sigma *******************************
/* Start sum at 0, the count at 1
We could also start with i as SUM = 0;
But we didn't. So until i is greater than 100
Add the value of i into SUM.
*/

/* let sum = 0;
for (let i = 1; i <= 100; i++) {
    sum += i;
    console.log(sum);
}
console.log(sum); */


// Factorial *****************************
/* Start with 1, and the count at 2, those are our starting
factorials, as well for logic. From the * by i and increment by 1.
Do this until the count is 12, then print the outcome.
*/

/* let product = 1;
for (let i = 2; i <= 12; i++) {
    product *= i;
}
console.log(product); 
*/