var pizza = {
    'crustType': ["deep dish", "hand tossed"],
    'sauceType': ["traditional", "marinara"],
    'cheeses': ["mozzarella", "feta"],
    'toppings': ["pepperoni", "sausage", "mushrooms", "olives", "onions"],
    'pizzaOven': function(crustType, sauceType, cheeses, toppings) {
        var pizza = {};
        pizza.crustType = crustType;
        pizza.sauceType = sauceType;
        pizza.cheeses = cheeses;
        pizza.toppings = toppings;
        return pizza;
    }
}    

var deepDish = pizza.pizzaOven("deep dish", "traditional", "mozzarella", "pepperoni, sausage");
console.log("deepDish pizza ---------")
console.log(deepDish);

var handTossed = pizza.pizzaOven("hand tossed", "marinara", "mozzarella, feta", "mushrooms, olives, onions");
console.log("handTossed pizza -------")
console.log(handTossed);

var deepDish2 = pizza.pizzaOven("deep dish", "marinara", "mozzarella, feta", "peperoni, sausage, onions");
console.log("deepDish pizza 2 --------")
console.log(deepDish2);
console.log("toppings for deepDish2: " + deepDish2.toppings);
var handTossed2 = pizza.pizzaOven("hand tossed", "traditional", "feta", "onions");
console.log("handTossed pizza 2 -------")
console.log(handTossed2);