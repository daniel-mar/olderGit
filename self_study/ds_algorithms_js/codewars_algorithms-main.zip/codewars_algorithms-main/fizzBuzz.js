/* Testing logic to understand modulus outputs
console.log( 10%3 );        // 1
console.log(9 % 3);         // 0 
console.log(10 % 2 == 0);   // true
console.log(12 % 5 == 0);   // false 
*/

/*  
Create For Loop to iterate through desired numbers  
check if number's modulus i % 3 == 0 ****** meaning it is a multiple 3
    if it is a multiple of 3. console.log --- Fizz

check if i % 5 == 0 ******** meaning it is a multiple of 5
    if it is a multiple of 5. console.log --- Buzz

check if i % 3 == 0 && i % 5 == 0 ****** meaning it is multiple of both
    if it is a multiple of both. console.log --- FizzBuzz
        else print all other numbers normally through the forloop
        
run fizzbuzz from 1 - 100, so condition must include the target
it runs and then when it hits 100, it breaks, and does not output another 100 (i)
*/

const target = 100;

for (let i = 1; i <= target; i++) {
    if (i % 3 == 0)
        console.log(i + " Fizz");
    if (i % 5 == 0)
        console.log(i + " Buzz");
    if (i % 3 == 0 && i % 5 == 0)
        console.log(i + " FizzBuzz");
    if (i == 100)
        break;
    else console.log(i);
}