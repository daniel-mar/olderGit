/* for my future referencing,

  ^ = start of a line, 
  \d = [0-9], {4} specifies 4 digits, 
  {6} specifies 6 digits, $ - end of a line
  
  first alternative ^\d{4}$ - equivalent to [0-9], matches exactly 4 digits.
  second alternative ^\d{6}$ - "", matches previous token exactly 6 digits.
  
   use RegEx .test to search for these characters stored.
   
*/ 

// practicing arrow function syntax
    //return true or false
    const validatePIN = pin => /^\d{4}$|^\d{6}$/.test(pin);

    var pin1 = "1234";
    var pin2 = "123456";
    var pin3 = "12345";
  
  console.log(validatePIN(pin1));
  console.log(validatePIN(pin2));
  console.log(validatePIN(pin3));