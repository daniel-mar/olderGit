# Codewars algorithm solutions

#### note: The comment sections contain notes that show the processes.
#### I also go through documentation and learn to come to the solution and I show when applicable.

