package binarytree;

public class binaryTree {
	
	Node root;

	
	// builds tree, inputted value [key] is less than root or parent
	// add new node insertedd left of parent, otherwise greater insert right of.
	public void addNode(int key, String name) {
		Node newNode = new Node(key, name);
		
		if(root == null) {
			root = newNode;
		} else {
			Node focusNode = root;
			
			Node parent;
			
			while(true) {
				parent = focusNode;
				
				if(key < focusNode.key) {
					focusNode = focusNode.leftChild;
					
					if(focusNode == null) {
						parent.leftChild = newNode;
						return;
					}
				} else {
					focusNode = focusNode.rightChild;
					
					if(focusNode == null) {
						parent.rightChild = newNode;
						return;
					}
				}
			}
		}
	} // end addNode
	
	// traverses and orders from least to greatest in testing
	public void inOrderTraverseTree(Node focusNode) {
		if(focusNode != null) {
			inOrderTraverseTree(focusNode.leftChild);
				System.out.println(focusNode);
			inOrderTraverseTree(focusNode.rightChild);
		}
	}
	
	// traverses and outputs prior to adjustments
	public void preorderTraverseTree(Node focusNode) {
		if(focusNode != null) {
			System.out.println(focusNode);
			
			preorderTraverseTree(focusNode.leftChild);
			preorderTraverseTree(focusNode.rightChild);
		}
	}
		// will output after ordering while continuing to traverse
		public void postOrderTraverseTree(Node focusNode) {
			if(focusNode != null) {
				
				postOrderTraverseTree(focusNode.leftChild);
				postOrderTraverseTree(focusNode.rightChild);
				
				System.out.println(focusNode);

			}			
	}
		
		
		public boolean remove(int key) {
			
			Node focusNode = root;
			Node parent = root;
			
			boolean isItALeftChild = true;
			
			while(focusNode.key != key) {
				
				parent = focusNode;
				
				if(key < focusNode.key) {
					
					isItALeftChild = true;
					
					focusNode = focusNode.leftChild;
				} else {
					
					isItALeftChild = false;
					
					focusNode = focusNode.rightChild;
				}
				
				// node never found
				if(focusNode == null)
					
					return false;
				
			} // end of while
			
			if(focusNode.leftChild == null && focusNode.rightChild == null) {
				
				if(focusNode == root) {
					
					root = null;
					
				} else if(isItALeftChild) {
					
					parent.leftChild = null;
					
				} else {
					
					parent.rightChild = null;
				}
			}
			
			// no right child
			else if(focusNode.rightChild == null) {
				
				if(focusNode == root)
					root = focusNode.leftChild;
				
				else if(isItALeftChild)
					parent.leftChild = focusNode.leftChild;
				
				else parent.rightChild = focusNode.leftChild;
				
			}
			
			// no left child
			else if(focusNode.leftChild == null) {
				
				if(focusNode == root)
					root = focusNode.rightChild;
				
				else if(isItALeftChild)
					parent.leftChild = focusNode.rightChild;
			
			else
				parent.rightChild = focusNode.leftChild;
			}
			
			else {
				
				Node replacement = getReplacementNode(focusNode);
				
				if(focusNode == root)
					root = replacement;
				
				else if(isItALeftChild)
					parent.leftChild = replacement;
				
				else
					parent.rightChild = replacement;
				
				replacement.leftChild = focusNode.leftChild;
			}
			
			return true;
			
		} // end remove(int key) boolean
		
		public Node getReplacementNode(Node replacedNode) {
			
			Node replacementParent = replacedNode;
			Node replacement = replacedNode;
			
			// moving right child up
			Node focusNode = replacedNode.rightChild;
			
			while(focusNode != null) {
				replacementParent = replacement;
				
				replacement = focusNode;
				
				// moving left child up
				focusNode = focusNode.leftChild;
			}
			
			if(replacement != replacedNode.rightChild) {
				
				replacementParent.leftChild = replacement.rightChild;
				replacement.rightChild = replacedNode.rightChild;
			}
			
			return replacement;
		}

		public Node findNode(int key) {
			Node focusNode = root;
			
			while(focusNode.key != key) {
				
				if(key < focusNode.key) {
					
					focusNode = focusNode.leftChild;
					
				} else {
					
					focusNode = focusNode.rightChild;
				}
				
				if(focusNode == null)
					return null;
			}
			
			return focusNode;
		}
		
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		binaryTree theTree = new binaryTree();
		
		// for us in remove
		binaryTree theSecondTree = new binaryTree();
		
		theTree.addNode(50, "Boss");
		theTree.addNode(25, "Vice Pres");
		theTree.addNode(15, "Office Manager");
		theTree.addNode(30, "Secretary");
		theTree.addNode(75, "Sales Manager");
		theTree.addNode(85, "Salesman 1");
		
		// this will output values that are increasing from least to greatest
		// this is what is in order traversal
		System.out.println("\nThe following is an example of in order traversal:");
		theTree.inOrderTraverseTree(theTree.root);
		
		// this will output values that are increasing from least to greatest
		// this is what is what preorder traversal looks like
		System.out.println("\nThe following is an example of pre order traversal with the same values");
		theTree.preorderTraverseTree(theTree.root);
		
		// this will jump to left child, check the left then right of that parents
		// check if those have children, then back to 50, check those left(none) and right children
		System.out.println("\nThe following is an example of post order traversal with same values");
		theTree.postOrderTraverseTree(theTree.root);
		
		System.out.println("\nWe will now search for a specific node(key) and who has it");
		System.out.println("Search for 30");
		System.out.println(theTree.findNode(30));
		
		System.out.println("\nThe above had not implemented remove.");
		System.out.println("NOTE:The following will have new values to than before\n");
		
		theSecondTree.addNode(50, "Boss");
		theSecondTree.addNode(25, "Vice Pres");
		theSecondTree.addNode(15, "Office Manager");
		theSecondTree.addNode(2, "Intern");
		theSecondTree.addNode(18, "Data Entry");
		theSecondTree.addNode(30, "Secretary");
		theSecondTree.addNode(75, "Sales Manager");
		theSecondTree.addNode(70, "Salesman 2");
		theSecondTree.addNode(85, "Salesman 1");
		
		System.out.println("Displaying first is the initial tree for comparison\n");
		theSecondTree.preorderTraverseTree(theSecondTree.root);
		
		System.out.println("\nREMOVE KEY 25\n");
		theSecondTree.remove(25);
		
		theSecondTree.preorderTraverseTree(theSecondTree.root);



		
	}
		
	class Node {
		int key;
		String name;
		
		Node leftChild;
		Node rightChild;
		
		Node(int key, String name) {
			this.key = key;
			this.name = name;
		}
		
		public String toString() {
			return name + " has a key " + key;
		}
		
	}
	

}
