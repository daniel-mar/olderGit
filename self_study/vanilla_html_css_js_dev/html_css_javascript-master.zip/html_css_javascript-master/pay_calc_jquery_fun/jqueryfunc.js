$("document").ready( function() {

	$("#payform").submit( function() {

		// obtain user input
		var empname = $("#empname").val();
		var payrate = parseFloat( $("#payrate").val() );
		var hours = parseInt( $("#hours").val() );

		if( empname == "" || isNaN(payrate) || isNaN(hours) ) {

			$("#output").hide( );
			$("#output").html( "Form not complete" );
			$("#output").show( "pulsate" );
			return;
		}

		// calculate total pay
		var totalpay = payrate * hours;

		// construct output
		var msg = "<div>Employee name is " + empname + "</div>";
		msg += "<div>Payrate is $" + payrate + "</div>";
		msg += "<div>Hours worked is " + hours + "</div>";
		msg += "<div>Total pay is $" + totalpay.toFixed(2) + "</div>";

		// send output to browser
		$("#output").hide( );
		$("#output").html( msg );
		$("#output").show( "slide" );

	} ); // ends submit handler code


	// code for the clear all button
	$("#clearbtn").click( function() {

		$(".fldcls").val( "" );
		$("#output").html( "" );

	} );

// top form sripts

	$("#styleform").submit( function() {

		var txtcolor = $("#txtcolor").val();
		var bkgcolor = $("#bkgcolor").val();
		var txtfont = $("#txtfont").val();

		$(".formtext").css( "color", txtcolor );
		$("body").css( "background-color", bkgcolor );
		$("body").css( "font-family", txtfont );

	} );

} ); // ends document.ready