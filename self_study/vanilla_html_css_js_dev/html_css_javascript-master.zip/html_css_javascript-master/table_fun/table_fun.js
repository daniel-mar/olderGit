function buildTable() {
 
    var startnum = parseInt( document.getElementById("startnum").value );
    var endnum = parseInt( document.getElementById("endnum").value );
     
    // we will begin contruction of the table prior to the loop
    // we do not want the top table row to be repeated,
    // only done one time
    var msg = "<table border='3' width='85%'>";
    msg += "<tr>";
    msg += "<td>Number</td>";
    msg += "<td>Square</td>";
    msg += "<td>Square Root</td>";
    msg += "</tr>";
     
    for( var count = startnum; count <= endnum; count++ ) {
     
     
    msg += "<td>" + count + "</td>";
    msg += "<td>" + Math.pow( count, 2 ) + "</td>";
    msg += "<td>" + Math.sqrt( count ).toFixed(3) + "</td>";
    msg += "</tr>";  
     
    } // ends the for loop
     
    msg += "</table>";
     
    // send output browser
    document.getElementById("output").innerHTML = msg;
     
    } // ends buildTable() function