// set variables for later use, shh ignore these
var totalCalWomen;
var totalCalMen;
var wBMR;
var mBMR;
var wPercent;
var mPercent;
 
  function calcCalories() {

	//parse input
	var weight = parseFloat( document.getElementById("weight").value );
	var height = parseFloat( document.getElementById("height").value );
	var age = parseFloat( document.getElementById("age").value ); 

	  // calculate Women BMR
	  wBMR = 655 + ( 4.3 * weight ) + ( 4.7 * height ) - ( 4.7 * age );

	  // calculate Men BMR
	  mBMR = 66 + ( 6.3 * weight ) + ( 12.9 * height ) - ( 6.8 * age );
  
	    // activity level 1-4 if statements
		if( document.getElementById("activity").value == "level1" ) {
      
		  wPercent = ( 20 / 100 ) * wBMR;
		  mPercent = ( 20 / 100 ) * mBMR;
		  totalCalWomen = wBMR + wPercent;	
		  totalCalMen = mBMR + mPercent;
		}
		  
		  else if( document.getElementById("activity").value == "level2" ) {
		    
		    wPercent = ( 37 / 100 ) * wBMR;
			mPercent = ( 37 / 100 ) * mBMR;
			totalCalWomen = wBMR + wPercent;
			totalCalMen = mBMR + mPercent;
		  }
			
		    else if( document.getElementById("activity").value == "level3" ) {
		  	  
		      wPercent = ( 55 / 100 ) * wBMR;
		      mPercent = ( 55 / 100 ) * mBMR;
		      totalCalWomen = wBMR + wPercent;
		      totalCalMen = mBMR + mPercent;
		      }
		  
		      else if( document.getElementById("activity").value == "level4" ) {
				
			    wPercent = ( 70 / 100 ) * wBMR;
			    mPercent = ( 70 / 100 ) * mBMR;
			    totalCalWomen = wBMR + wPercent;
			    totalCalMen = mBMR + mPercent;  
				}
				
      // construct output		  
		var msg = "<div>To maintain your current weight...</div>";
		msg += "<div>If you are female, you may eat " + totalCalWomen.toFixed() + " calories.</div>";
		msg += "<div>If you are male, you may eat " + totalCalMen.toFixed() + " calories.</div></br>";
		msg += "<div>More calories in a day will result in weight gain,</div>";
		msg += "<div>less calories will result in weight loss.</div>";


    // output
            document.getElementById("output").innerHTML = msg;
			
  // ends function  
  }