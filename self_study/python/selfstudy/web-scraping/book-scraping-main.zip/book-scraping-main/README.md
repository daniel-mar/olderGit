# book-scraping
practicing web-scraping in python using modules [requests, beautiful soup]

Gaining familiarity with for loops, variables and basic syntax of the language & modules.
URL has been commented out, the program when ran without comment will otherwise loop through 1-51, or the 1-50 of the site's pages.
Collect the data we want, clean it of white space or excess values and store within our dictionary.
At the end, because it is 1000 books, to minimize the printable outcome and practice syntax, print the first 10 books.
I have confirmed that the books printed are the 10 from the website, refer to screenshot for comparison.
