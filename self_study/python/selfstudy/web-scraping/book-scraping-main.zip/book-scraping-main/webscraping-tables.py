import requests
from bs4 import BeautifulSoup

book_list = []

for x in range(1,51):
    print(x)
    url = f'https://books.toscrape.com/catalogue/page-{x}.html'

    r = requests.get(url)

    # included html.parser, to be direct.
    soup = BeautifulSoup(r.text, 'html.parser')

    # narrow down to article class 'product_pod'
    article = soup.find_all('article', class_ = 'product_pod')

    # narrow down to books within article, searching for a tag, but the second one.
    for book in article:
            title = book.find_all('a')[1]['title']
            # because return has integers and 2 strings infront of them, we will slice them of via [2:]
            price = book.find('p', class_ = 'price_color').text[2:]
            # use .strip to rid of unnecessary whitespace
            instock = book.find('p', class_ = 'instock availability').text.strip()
            books = {
                'title': title,
                'price': price,
                'instock': instock
            }
            book_list.append(books)

print(book_list[0:10])