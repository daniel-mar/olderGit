# Project Week - Scraping into HTML

## Project goal: To learn about scraping data from static or dynamic websites for repurposing.
### There are two projects developed throughout project week.

- Scraping to view .csv on HTML dashboard | Python, BeautifulSoup(BS4), HTML, PapaParse.js, JavaScript.
#### Using PapaParse.js, create a dynamic table from a selected .csv file within end user device. 
- Scraping onto custom website. | Python, BeautifulSoup(BS4), HTML, CSS, Bootstrap.js, JavaScript, Jinja3.
#### Create a responsive website to scrape a website on load and display data on desired @app.route.
##### Rewrite scraper into a class, modularize the project to run app through the server.
##### On page load, run python model to gather data and access via Jinja3.
