from selenium import webdriver
from selenium.webdriver.common.by import By

import pandas as pd

# *** DESCRIPTION ***
# use selenium to extract data from dynamic site (manually sorted on site, filtered prior to use).
# context: youtube channel dedicated to cooking different themes of foods. Can be interchanged.

url = 'https://www.youtube.com/c/JoshuaWeissman/videos?view=0&sort=p&flow=grid'

def get_youtube_table(url):
    driver = webdriver.Chrome()
    driver.get(url)

    video_list = []

    videos = driver.find_elements(By.CLASS_NAME, 'style-scope ytd-grid-video-renderer')

    for video in videos:
        # driver.find_element ... may get the first one only, we'd like EACH one for every video.
        # '.'before the // searches all with the element, not the entire page.
        # NOTICE: '.' is important in order to get the unique per video text.
        title = video.find_element(By.XPATH, './/*[@id="video-title"]').text
        views = video.find_element(By.XPATH, './/*[@id="metadata-line"]/span[1]').text
        when = video.find_element(By.XPATH, './/*[@id="metadata-line"]/span[2]').text
        
        # create dict to pass to list, setup before exporting.
        vid_item = {
            'title': title,
            'views': views,
            'posted': when
        }
        video_list.append(vid_item)
    return video_list    

    # close site after extracting data, also way to know program terminated besides print(). 
    driver.close()

# call function, store list into data variable, convert into a DataFrame & convert to .csv file.
data = get_youtube_table(url)
df = pd.DataFrame(data)
df.to_csv('joshua_weissman_sorted_by_popularity_videos.csv', index=False)

print("completed creation of csv file for channel's most popular list.")