# youtube_popularity_scrape

practicing with selenium module. I wanted to begin practicing with automation and dynamic websites as I build it bigger onto previous knowledge.

errors met --- webdrivers path, deprecated functions via selenium, key words used for extracting individual videos.

resolved via --- webdriver: downloaded .exe and create path, add into environment.

deprecated functions: import specifically 'from selenium.webdriver.common.by import By

previously would use find_element_by_xpath
this was deprecated from selenium version installed. After importing the By and adjusting the function call, it was able to work with new parameters.

this became '.find_element(By.XPATH, 'desired-element')

use and expanded on via -- making sure it worked, created into a fucntion to be called to open connection and closing after extracting the desired content and creating a DataFrame. Have removed index created from pandas dataframes, CSV results are as desired now.
