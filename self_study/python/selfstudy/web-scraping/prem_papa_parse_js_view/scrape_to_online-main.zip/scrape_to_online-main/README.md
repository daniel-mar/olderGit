# Scrape data to view online

### Scraped data to .csv and dynamically display that scraped data among other .csv files on a website
#### Included in the github is the scrape.py to scrape data from the website. As well as the output of the program running, ("league_stats.csv"). There is more data that can be downloaded in order to use for uploading to the website, in order to view the dynamic updating of each table.
