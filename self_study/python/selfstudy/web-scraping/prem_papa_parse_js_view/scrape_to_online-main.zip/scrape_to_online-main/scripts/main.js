import TableCsv from "./TableCsv.js";

const tableRoot = document.querySelector("#csvRoot");
const csvFileInput = document.querySelector("#csvFileInput");
const tableCsv = new TableCsv(tableRoot);


// passes in the body, passes in the headers. (note: does not need to have the header section)
// tableCsv.update([
//     [4500, "dom", 35],
//     [4500, "dom", 35],
//     [4500, "dom", 35]   
// ], ["ID", "Name", "Age"]);


csvFileInput.addEventListener("change", e => {
    Papa.parse(csvFileInput.files[0], { 
        delimiter: ",",
        skipEmptyLines: true,
        complete: results => {
            tableCsv.update(results.data.slice(1), results.data[0]);
        }
    });
});


// // setup the default table headers
// tableCsv.setHeader(["ID", "Name", "Age"]);
// tableCsv.setBody([
    
// ])