import requests
from bs4 import BeautifulSoup

r = requests.get('https://www.skysports.com/premier-league-table')
soup = BeautifulSoup(r.text, 'html.parser')
# get table we desire to scrape, look into table tag
league_table = soup.find('table', class_ = 'standing-table__table callfn')

print("  Team     P1")

# from the league_table look into tbody tag, search through tr
for team in league_table.find_all('tbody'):
    rows = team.find_all('tr')

    for row in rows:
        rank = row.find_all('td', class_ = 'standing-table__cell')[0].text
        pl_team = row.find('td', class_ = 'standing-table__cell standing-table__cell--name').text.strip()
        played = row.find_all('td', class_ = 'standing-table__cell')[2].text
        won = row.find_all('td', class_ = 'standing-table__cell')[3].text
        drawn = row.find_all('td', class_ = 'standing-table__cell')[4].text
        lost = row.find_all('td', class_ = 'standing-table__cell')[5].text
        gf = row.find_all('td', class_ = 'standing-table__cell')[6].text
        ga = row.find_all('td', class_ = 'standing-table__cell')[7].text
        gd = row.find_all('td', class_ = 'standing-table__cell')[8].text
        points = row.find_all('td', class_ = 'standing-table__cell')[9].text


        print(rank, pl_team, played, won, drawn, lost, gf, ga, gd, points)