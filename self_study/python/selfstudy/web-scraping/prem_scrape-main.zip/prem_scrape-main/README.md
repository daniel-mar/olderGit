# prem_scrape
two different versions of leaderboards, first would be the easiest to practice, second to see how formatting would be done for readability.

the final version is ***  prem_scrape_to_cvs.py  *** YES CVS NOT CSV, sometimes I make small personal projects have puns.
### 
****** files with that final version include the following ******
exported csv:                          leaguetable_2021.csv
view testing prior:                    prem_scrape_pandas_dataframe.png
Google Sheets results of exported csv: premiere_league_standings_2021.png

I wanted to practice not only scraping the data, creating a function, cleaning up the code where formatting would not be needed much in or out of python.
The goal was to have correct formatting when exporting, to ease data-cleaning if any necessary. Which it was, with a carryover of the index made via pandas dataframes.
I imagine I could do df.index += 1, with the assumption of rank being index. But for the sake of project, overall understanding entering the data-cleaning process. 
That may cause errors if my original scraping of site was not accurate in the ranks for whatever reason.
I believe leaving the deletion of index and leaving the rank there as original would be better. For a quick column deletion in this dataset would be cleaned and ready.
For whoever views the file would understand that there was no manipulation done. 

--- Data Cleaning, confirmation that data would be readable and could proceed to .csv exporting
Using a dict in python, labeling and using scraped data to fill it and append to array for later use.
Created pandas data frame, printed data via df.head() ---- refer to image for the output [prem_scrape_pandas_dataframe.png]
After data cleaning was confirmed accurate via df.head(), convert to .csv and export. With a message confirming results.

Overall, fun project, a lot of documentation & reading, videos. 
A few of the errors I had were understanding the versions of python & location installed with VSCode for cmd, pip installing within project.
Added a view extensions for python development.

Possible projects to carry this forward, would be use historical data. Begin to learn and apply machine learning.
Make predictions of winners, by points, or goals, etc.
