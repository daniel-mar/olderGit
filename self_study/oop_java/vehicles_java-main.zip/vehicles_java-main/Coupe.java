//child
public class Coupe extends Vehicle {
    private int twoDoors;

    //parameterized COUPE construct
    public Coupe(String n, int c, int td) {
        super(n, c); // call parent constructor
        this.twoDoors = td;
    }

    //default COUPE constructor
    public Coupe() {
        super();
        this.twoDoors = 0;
    }

    //getter in Coupe
    public double getTwoDoors() {
        return this.twoDoors;
    }

    //find two doors
    public int findTwoDoors() {
        return (this.twoDoors);
    }

    //OVERRIDE isEqual()
    public boolean isEqual(Coupe otherC) {
        if(super.isEqual(otherC) == true &&
        this.twoDoors == otherC.getTwoDoors() )
            return true;
        else
            return false;
    }

    //OVERRIDE toString()
    public String toString() {
        return super.toString() +
        "\nHas " + this.twoDoors + " doors";
    }

}
