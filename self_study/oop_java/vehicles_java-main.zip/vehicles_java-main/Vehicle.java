//parent
public class Vehicle {

	private String name;
	private int cylinders;
	
	
	//parameterized VEHICLE construct
	public Vehicle( String n, int c ) {
		
		this.name = n;
		this.cylinders = c;
		}
	
	//default construct
	public Vehicle() {
		
		this.name = "Generic";
		this.cylinders = 0;
	}
	
	
	//GETTERS!! GETTERS!! GET YOUR GETTERS HERE
	public String getName() {
		
		return this.name;
	}
	
	public int getCylinders() {
		
		return this.cylinders;
	}
	
	
	
	//INSTANCE METHODS
	
	//isEqual() 
	public boolean isEqual( Vehicle otherV ) {
		if( this.cylinders == otherV.getCylinders() &&
			this.name.equals(otherV.getName() ) ) 
			
			return true;
		
		else
			return false;
		
	} //end isEqual
	
	
	
	//toString()
	public String toString() {
		
		return "Manufacturer Name: " + this.name +
				"\nNumber of Cylinders: " + this.cylinders;
		
		
	}
	
} //end PARENT class