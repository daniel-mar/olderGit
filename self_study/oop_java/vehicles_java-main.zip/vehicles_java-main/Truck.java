//child
public class Truck extends Vehicle {

	private double loadCap;
	
	
	//parameterized TRUCK construct
	public Truck( String n, int c, double lc ) {
		
		super( n, c ); //call PARAMETERIZED from parent 
		this.loadCap = lc;
	}
	
	//default TRUCK construct
	public Truck() {
		
		super(); //call DEFAULT from parent
		this.loadCap = 0.0;
	}
	
	
	//GETTER in TRUCK
	public double getLoadCap() {
		
		return this.loadCap;
	}
	
	
	
	//find Tow Capacity
	public double findTowCap() {
		
		//converts TON to POUNDS
		//otherwise *2000 is not necessary
		//but output is usually small: 0.1231231 etc etc 
		return	( this.loadCap * 2000 ) / this.getCylinders();
	}
	
	
	//OVERRIDE isEqual()
	public boolean isEqual( Truck otherT ) {
		
		if( super.isEqual(otherT) == true &&
			this.loadCap == otherT.getLoadCap() )
			return true;
		else
			return false;
	}
	
	
	//OVERRIDE toString()
	public String toString() {
		
		return super.toString() + 
				"\nLoad Capacity: " + this.loadCap + " tons";
	}
	
	
} //end CHILD blueprint
