//DRIVER for vehicle
public class VehicleTest {

	public static void main(String[] args) {

		Truck t1 = new Truck( "Toyota TRD Pro", 6, 4.7 );
		Truck t2 = new Truck( "Nissan Avalanche", 6, 3.7 );

		Sedan s1 = new Sedan("Toyota Camry", 6, 4);
		
		Coupe c1 = new Coupe("Nissan Fairlady Z", 6, 2);
		Coupe c2 = new Coupe("Nissan Fairlady Z", 6, 2);

		
		System.out.println( t1 );
		System.out.println( "Tow Capacity: " + t1.findTowCap() + " pounds");
		
		System.out.println( "\n" + t2 );
		System.out.println( "Tow Capacity: " + t2.findTowCap() + " pounds");
	
		System.out.println("\n" + s1);
		System.out.println("Number of doors: " + s1.findFourDoors() + " doors");

		System.out.println("\n" + c1);
		System.out.println("Number of doors: " + c1.findTwoDoors() + " doors");



		
		if( t1.isEqual( t2 ) == true )
			System.out.println( "\nTesting t1 to t2, They are the exact same vehicle");
		else
			System.out.println( "\nTesting t1 to t2, They are not the exact same vehicle");

		if(s1.isEqual(c1) == true)
			System.out.println("\nTesting s1 to c1, They are the exact same vehicle");
		else
			System.out.println("\nTesting s1 to c1, They are not the same exact vehicle");

		if(c1.isEqual(c2) == true)
			System.out.println("\nTesting c1 to c2, They are the exact same vehicle");
		else
			System.out.println("\nTesting c1 to c2, They are not the same exact vehicle");

	}
}
