//child
public class Sedan extends Vehicle {

   private int fourDoors;

   //parameterized SEDAN construct
   public Sedan(String n, int c, int fd) {

        super(n, c); // call parameterized from parent
        this.fourDoors = fd;
   }


   // default SEDAN constructor
   public Sedan() {

        super();
        this.fourDoors = 0;
   }

   //getter in Sedan
   public double getFourdours() {
        return this.fourDoors;
   }

   //find four doors
   public int findFourDoors() {
        return (this.fourDoors);
   }

   //OVERRIDE isEqual()
   public boolean isEqual(Sedan otherS) {
       if(super.isEqual(otherS) == true &&
       this.fourDoors == otherS.getFourdours() )
            return true;
        else
            return false;
   }

   //OVERRIDE toString()
   public String toString() {
       return super.toString() +
        "\nHas " + this.fourDoors + " doors";

   }

}