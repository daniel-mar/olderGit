# credit_car
practicing inheritance, polymorphism, object oriented programming
create money object, that creditcard object uses, and create different types of cards, test out some functionality.

Creating the money to except string input from the user, parse it into workable numbers. Readable similar to how we read money ourselves.
Has functionality of adding and subtracting money values. This was previously used in a simple ATM to perform set balance arithmethic.
Add, subtract, multiplication, and comparing values. It has now been used to create a credit card and add readability to that. 
To understand how fees may work on initial card opening and manipulating default toString values. REFER TO CreditCard.java.

*********
CreditCard.java allows payment to pay off balance of a credit card that we have set up in a test. Along with default values that will create
card objects from. You will note that CreditCard.java does accept payment and subjracts money object and updates balance accordingly using the Money
methods, allowing for boolean testing to be done in TestCreditCard.java to check if balance is allowed to be overpaid (it does not allow this). I am aware
in modern times, credit to be added is becoming more prevalent and roll over into the following months, but I chose not to accept such things at all.

MasterCrook, DishonestExpress, TestCreditCard (MasterCrook & DishonestExpress) are similar except in the service fee and interest, the service fee
is applied at card opening, while the interest was not supposed to be applicable in the testing, due to being date periods to add to balance. 
I did fill out these values and allowed the service feem, payCard(), chargeCard() to be the main manipulation, simulating a purchase and paying balance.

This was done to practice a little of arrays, composition and inheritance and will admit that it could be more fleshed out, have more functionality.
As practice, I enjoyed this project and the different levels to it. It holds more depth than the Vehicle classes I had worked on and that gave me satisfaction in itself.

I will say, it was a move from Eclipse, to VSCode and working a bit more with Github.
