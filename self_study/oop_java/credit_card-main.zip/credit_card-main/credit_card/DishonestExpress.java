
public class DishonestExpress extends CreditCard {

	private int interest;
	
	
	
	//parameterized
	public DishonestExpress( String id, int inter ) {
		super.getIDnum();
		this.interest = inter;
		
	}
	 
	//default
	public DishonestExpress() {
		
		super();
		this.interest = 2;
	}
	
	

	//getter
	public int getInterest() {
		
		return this.interest;
	}

	
	
	//override chargeCard()
	public void chargeCard( Money charamt ) {
		
		((CreditCard)this).setBalance( charamt );
	}
	
}
