
public class MasterCrook extends CreditCard {

	private Money servicefee;
	
	
	
	//Parameterized
	public MasterCrook( String id, Money sf ) {
		
		super.getIDnum();
		this.servicefee = sf;
	}
	
	//default
	public MasterCrook() {
		
		super();
		this.servicefee = new Money("$5.00");
	}
	
	
	
	//getter
	public Money getServiceFee() {
		
		return this.servicefee;
	}
	
	
	
	//override chargeCard()
	public void chargeCard( Money chargeamt ) {

		((CreditCard)this).setBalance( chargeamt ) ;
	}
	
}