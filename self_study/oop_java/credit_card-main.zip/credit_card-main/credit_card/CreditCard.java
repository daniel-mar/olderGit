public abstract class CreditCard {

	private String idnum;
	private Money balance;
	
	
	
	//Parameterized Construct
	public CreditCard( String id, Money bal ) {
		
		this.idnum = id;
		this.balance = new Money();
	}
	
	//OVERLOAD parameterized
	public CreditCard( Money bal, String id ) {
		
		this.idnum = "000000";
		this.balance = new Money( "$0.00" );
	}
	
	//default Construct
	public CreditCard() {
		
		this.idnum = "000000";
		this.balance = new Money(); //calls default MONEY
	}
	
	
	
	//GETTERS	
	public String getIDnum() {
		
		return this.idnum;
	}
	
	public Money getBalance() {
		
		return this.balance;
	}
	
	
	
	//INSTANCE METHODS
	public void setBalance( Money balamt ) {
		
		this.balance = balamt;
		
	}
	
	//payment check
	public boolean payCard( Money payamt ) {
		
		if( this.balance.compareMoney( payamt ) >= 0 ) {
			
			this.balance = this.balance.subtractMoney( payamt );
			return true;			
		}
		
		else
		return false;
		
	}
	
	
	
	//Abstract
	public abstract void chargeCard( Money chargeamt );
	
	
	
	//toString
	public String toString() {
		
		String msg = "";
		
		if( this instanceof MasterCrook ) {
			System.out.println( "\nCard: Master Crook"  );
			System.out.println( "Service multiplier: " + ((MasterCrook)this).getServiceFee() );
			System.out.println( "Balance: " + ((MasterCrook)this).getBalance() );

	}
		else {
		
			System.out.println( "\nCard: Dishonest Express" );
			System.out.println( "Interest Amount: " + ((DishonestExpress)this).getInterest() );
			System.out.println( "Balance: " + ((DishonestExpress)this).getBalance() );
		}
		
		return msg;
	}
		
	
} //end CLASS
